import { proto } from '@whiskeysockets/baileys';
import { prisma } from '../config/prisma';
import { aiReplyQueue } from '../queues';
import { debounceQueue } from '../queues/debounce.queue';
import { logger } from '../utils/logger';
import { env } from '../config/env';
import { baileysManager } from './baileys.service';
import { getIO } from '../websocket/handler';
import { DEBOUNCE_MS, DEBOUNCE_MAX_CHUNKS, pushDebounceChunk } from './state.service';

// ──────────────────────────────────────────────────────────────────────────────
// FITUR OPERASIONAL — Fase 5
// ──────────────────────────────────────────────────────────────────────────────

// ── 1. Anti-Spam Debounce ─────────────────────────────────────────────────────
// Kumpulkan pesan beruntun dalam 4 detik → gabung jadi 1 sebelum ke AI.
//
// Fix audit A5: buffer-nya tidak lagi Map in-memory + setTimeout. Chunk disimpan
// di Redis dan flush-nya dijadwalkan lewat BullMQ delayed job, jadi aman untuk
// multi-instance dan tidak bocor memori. Batas 10 chunk (fix B7) sekarang
// ditegakkan secara atomik di dalam script Lua di state.service.ts.
// Lihat: state.service.ts, queues/debounce.queue.ts, queues/debounce.worker.ts

// ── 2. Menu Hardcoded Bypass AI ───────────────────────────────────────────────
// Angka 1/2/3 → balasan statis instan, 0 token Groq
// Konfigurasi bisa diambil dari business.settings, ini default fallback
const DEFAULT_MENU: Record<string, string> = {
  '1': '📦 *Cara Order:*\n1. Pilih produk\n2. Chat kami dengan format: PESAN [Nama Produk] [Jumlah]\n3. Kami konfirmasi & kirim invoice\n4. Transfer sesuai invoice\n5. Barang dikirim! 🚀',
  '2': '💳 *Cara Pembayaran:*\nKami menerima:\n• Transfer Bank (BCA/Mandiri/BRI)\n• QRIS (semua e-wallet)\n• COD area tertentu\n\nSetelah transfer, kirim bukti ke chat ini ya Kak 😊',
  '3': '📞 *Hubungi CS Manusia:*\nKetik *0* untuk terhubung dengan tim CS kami.\nJam operasional: Senin-Sabtu, 08.00-17.00 WIB',
  '0': null as any, // 0 = trigger handover ke human (ditangani terpisah)
};

// ── 3. Hot Lead Detection ─────────────────────────────────────────────────────
// Deteksi sinyal beli → notif rahasia ke Admin via WebSocket
const HOT_LEAD_KEYWORDS = [
  'mau beli', 'mau pesan', 'mau order', 'mau transfer',
  'bisa transfer', 'cara beli', 'cara order', 'cara pesan',
  'harga berapa', 'ada stok', 'ready ga', 'ready gak',
  'minat', 'tertarik', 'saya beli', 'saya order',
  'transfer ke mana', 'rekening', 'no rek',
];

function detectHotLead(text: string): boolean {
  const lower = text.toLowerCase();
  return HOT_LEAD_KEYWORDS.some(kw => lower.includes(kw));
}

// ── 4. Rate Limiting per Lead ─────────────────────────────────────────────────
// Cek daily_ai_count vs cap dari env (GROQ_DAILY_CAP_PER_LEAD)
// daily_ai_count direset setiap hari via cron (belum ada, nanti Fase 6 atau manual)
async function isRateLimited(leadId: string): Promise<boolean> {
  const lead = await prisma.lead.findUnique({
    where: { id: leadId },
    select: { dailyAiCount: true },
  });
  return (lead?.dailyAiCount ?? 0) >= env.GROQ_DAILY_CAP_PER_LEAD;
}

// ── Helper: respond dengan pesan hardcoded ────────────────────────────────────
async function sendHardcodedReply(
  businessId: string,
  conversationId: string,
  leadId: string,
  waJid: string,
  replyText: string,
): Promise<void> {
  await prisma.message.create({
    data: {
      businessId,
      conversationId,
      leadId, // Fix C5: denormalisasi — query konteks AI tak perlu JOIN ke conversations
      message: replyText,
      messageType: 'text',
      fromRole: 'AI',
      aiModel: 'hardcoded',
    },
  });

  // Kirim via Baileys langsung (bypass queue untuk kecepatan)
  try {
    await baileysManager.sendMessage(businessId, waJid, { text: replyText });
  } catch (err) {
    logger.warn(`[Hardcoded] Failed to send WA message: ${err}`);
  }

  const io = getIO();
  if (io) {
    io.to(`business:${businessId}`).emit('chat:new', {
      conversationId,
      message: { fromRole: 'AI', message: replyText, createdAt: new Date() },
    });
  }
}

// ── Helper: trigger human handover ───────────────────────────────────────────
async function triggerHandover(
  businessId: string,
  conversationId: string,
  leadId: string,
  waJid: string,
): Promise<void> {
  await prisma.conversation.update({
    where: { id: conversationId },
    data: { status: 'HUMAN' },
  });

  const handoverMsg = '⏳ Oke Kak, tunggu ya. Tim CS kami akan segera membalas dalam beberapa menit! 🙏';
  await sendHardcodedReply(businessId, conversationId, leadId, waJid, handoverMsg);

  // Notifikasi admin
  const io = getIO();
  if (io) {
    io.to(`business:${businessId}`).emit('chat:handover', {
      conversationId,
      leadId,
      reason: 'manual_request',
    });
    io.to(`business:${businessId}`).emit('chat:status', {
      conversationId,
      status: 'HUMAN',
    });
  }
  logger.info(`[Handover] Conv ${conversationId} handed to HUMAN (lead typed "0")`);
}

// ── Helper: enqueue AI reply dengan rate-limit check ─────────────────────────
// Diekspor karena sejak fix A5 pemanggilnya adalah debounce.worker.ts (proses
// terpisah), bukan lagi callback setTimeout di dalam file ini.
export async function enqueueAiReply(
  businessId: string,
  conversationId: string,
  leadId: string,
  messageText: string,
  leadName: string | null,
  waJid: string,
): Promise<void> {
  const limited = await isRateLimited(leadId);
  if (limited) {
    logger.info(`[RateLimit] Lead ${leadId} exceeded daily AI cap (${env.GROQ_DAILY_CAP_PER_LEAD})`);
    const limitMsg = '⚠️ Maaf Kak, batas pesan hari ini sudah tercapai. Silakan hubungi kami kembali besok atau ketik *0* untuk chat langsung dengan CS kami 😊';
    await sendHardcodedReply(businessId, conversationId, leadId, waJid, limitMsg);
    return;
  }

  await aiReplyQueue.add('generate-reply', {
    businessId,
    conversationId,
    leadId,
    messageText,
    leadName,
    waJid,
  }, {
    priority: 1,
    jobId: `ai-reply-${conversationId}-${Date.now()}`,
  });

  // Increment daily AI count
  // Catatan (fix audit A1): increment HANYA di sini, tidak di ai.service.ts.
  await prisma.lead.update({
    where: { id: leadId },
    data: { dailyAiCount: { increment: 1 } },
  });
}

// ──────────────────────────────────────────────────────────────────────────────
// MAIN HANDLER — handleIncomingMessage
// Pipeline: filter → debounce → hardcoded menu check → hot lead → AI queue
// ──────────────────────────────────────────────────────────────────────────────
export async function handleIncomingMessage(businessId: string, msg: proto.IWebMessageInfo) {
  try {
    const key = msg.key;
    const remoteJid = key?.remoteJid;

    // ── Filter 1: Abaikan pesan grup ──────────────────────────────────────────
    if (!remoteJid || remoteJid.endsWith('@g.us')) return;

    // ── Filter 2: Hanya pesan teks ────────────────────────────────────────────
    const messageText = (
      msg.message?.conversation ||
      msg.message?.extendedTextMessage?.text ||
      ''
    ).trim();

    if (!messageText) {
      // Abaikan gambar, video, dokumen, stiker secara silent
      logger.debug(`[MessageSvc] Non-text message from ${remoteJid} — skipped`);
      return;
    }

    const waNumber = remoteJid.split('@')[0]!;
    const waId = remoteJid;

    // ── Upsert Lead ───────────────────────────────────────────────────────────
    let lead = await prisma.lead.findUnique({
      where: { businessId_waNumber: { businessId, waNumber } },
    });
    if (!lead) {
      lead = await prisma.lead.create({
        data: {
          businessId,
          name: msg.pushName || null,
          waNumber,
          waId,
          status: 'ACTIVE',
        },
      });
      logger.info(`[MessageSvc] New lead: ${waNumber} (business: ${businessId})`);
    }

    // ── Upsert Conversation ───────────────────────────────────────────────────
    let conversation = await prisma.conversation.findFirst({
      where: { businessId, leadId: lead.id, status: { in: ['AI', 'HUMAN'] } },
    });
    if (!conversation) {
      conversation = await prisma.conversation.create({
        data: { businessId, leadId: lead.id, status: 'AI' },
      });
    }

    // ── Save pesan masuk ke DB ────────────────────────────────────────────────
    const savedMessage = await prisma.message.create({
      data: {
        businessId,
        conversationId: conversation.id,
        leadId: lead.id, // Fix C5: denormalisasi leadId
        message: messageText,
        messageType: 'text',
        fromRole: 'LEAD',
      },
    });

    await prisma.lead.update({
      where: { id: lead.id },
      data: { lastMessageAt: new Date(), totalMessages: { increment: 1 } },
    });

    // Emit chat baru ke dashboard
    const io = getIO();
    if (io) {
      io.to(`business:${businessId}`).emit('chat:new', {
        conversationId: conversation.id,
        message: { ...savedMessage, fromRole: 'LEAD' },
        lead: { id: lead.id, name: lead.name, waNumber: lead.waNumber },
      });
    }

    // ── Jika HUMAN mode: stop di sini, CS manusia yang balas ─────────────────
    if (conversation.status === 'HUMAN') return;

    // ── Hardcoded Menu Check: "0" = handover ──────────────────────────────────
    if (messageText === '0') {
      await triggerHandover(businessId, conversation.id, lead.id, waId);
      return;
    }

    // ── Hardcoded Menu Check: "1"/"2"/"3" = balasan statis ───────────────────
    if (messageText in DEFAULT_MENU && DEFAULT_MENU[messageText]) {
      await sendHardcodedReply(
        businessId, conversation.id, lead.id, waId,
        DEFAULT_MENU[messageText],
      );
      return;
    }

    // ── Hot Lead Detection ────────────────────────────────────────────────────
    if (detectHotLead(messageText)) {
      logger.info(`[HotLead] 🔥 Lead ${lead.id} (${waNumber}) detected as HOT`);
      await prisma.lead.update({
        where: { id: lead.id },
        data: { score: { increment: 10 }, intent: 'BUYING' },
      });
      if (io) {
        io.to(`business:${businessId}`).emit('lead:hot', {
          leadId: lead.id,
          leadName: lead.name,
          waNumber,
          conversationId: conversation.id,
          trigger: messageText.slice(0, 80),
          timestamp: new Date().toISOString(),
        });
      }
    }

    // ── Anti-Spam Debounce (4 detik) — Fix A5: Redis + BullMQ delayed job ─────
    // Tiap pesan menaikkan nomor generasi buffer dan menjadwalkan job flush
    // baru. Job generasi lama otomatis jadi basi dan no-op saat fired, jadi
    // efeknya sama seperti clearTimeout() versi lama — tapi tanpa state lokal.
    const pushed = await pushDebounceChunk(businessId, waNumber, messageText, {
      conversationId: conversation.id,
      leadId: lead.id,
      leadName: lead.name,
      waJid: waId,
    });

    if (!pushed) {
      // Redis bermasalah — jangan sampai pesan pelanggan hilang diam-diam.
      // Lewati debounce, langsung antre balasan untuk pesan ini saja.
      logger.warn(`[Debounce] Buffer Redis gagal untuk ${waNumber} — fallback enqueue langsung`);
      await enqueueAiReply(businessId, conversation.id, lead.id, messageText, lead.name, waId);
      return;
    }

    if (pushed.dropped) {
      logger.warn(`[Debounce] Lead ${waNumber} hit ${DEBOUNCE_MAX_CHUNKS}-chunk limit -- excess message dropped`);
    }

    // Sengaja TIDAK memakai jobId kustom. jobId deterministik seperti
    // `debounce-<business>-<wa>-<generasi>` terlihat rapi tapi berbahaya di sini:
    // nomor generasi kembali ke 1 setiap buffer selesai di-flush, sementara
    // BullMQ masih menyimpan job lama yang sudah completed (removeOnComplete:
    // 200). Menambahkan job dengan jobId yang sudah ada TIDAK menjadwalkan job
    // baru — ia mengembalikan job lama diam-diam, sehingga buffer tidak pernah
    // di-flush dan pesan pelanggan menggantung sampai TTL habis.
    // Pengaman terhadap flush ganda sudah dipegang oleh pengecekan generasi di
    // state.service.ts, jadi id otomatis dari BullMQ sudah cukup dan lebih aman.
    await debounceQueue.add(
      'flush',
      { businessId, waNumber, generation: pushed.generation },
      { delay: DEBOUNCE_MS },
    );
  } catch (error: any) {
    logger.error(`[MessageSvc] Error handling message: ${error.message}`, { stack: error.stack });
  }
}
