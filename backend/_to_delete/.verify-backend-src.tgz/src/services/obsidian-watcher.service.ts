import chokidar, { FSWatcher } from 'chokidar';
import fs from 'fs/promises';
import path from 'path';
import matter from 'gray-matter';
import { prisma } from '../config/prisma';
import { knowledgeService } from './knowledge.service';
import { logger } from '../utils/logger';
import { env } from '../config/env';

// ──────────────────────────────────────────────────────────────────────────────
// Tipe helper internal
// ──────────────────────────────────────────────────────────────────────────────
interface SyncStats {
  totalSynced: number;
  totalDeleted: number;
  lastSyncAt: Date | null;
  isWatching: boolean;
  vaultPath: string;
}

// ──────────────────────────────────────────────────────────────────────────────
// ObsidianWatcherService
// Memantau folder SalesPintar-CS-Brain 24/7.
// Setiap file .md baru/diubah → embed → upsert ke tabel knowledge.
// File .md dihapus → hapus record dari DB (berdasarkan sourceFile).
// ──────────────────────────────────────────────────────────────────────────────
class ObsidianWatcherService {
  private watcher: FSWatcher | null = null;
  private debounceMap: Map<string, NodeJS.Timeout> = new Map();
  private stats: SyncStats = {
    totalSynced: 0,
    totalDeleted: 0,
    lastSyncAt: null,
    isWatching: false,
    vaultPath: '',
  };

  // ─── Public API ─────────────────────────────────────────────────────────────

  async start(): Promise<void> {
    const vaultPath = env.OBSIDIAN_CS_PATH;
    if (!vaultPath) {
      logger.warn('[ObsidianWatcher] OBSIDIAN_CS_PATH tidak diset di .env — watcher tidak diaktifkan');
      return;
    }

    this.stats.vaultPath = vaultPath;

    // Pastikan folder vault ada
    try {
      await fs.access(vaultPath);
    } catch {
      logger.warn(`[ObsidianWatcher] Folder vault tidak ditemukan: ${vaultPath} — watcher tidak diaktifkan`);
      return;
    }

    logger.info(`[ObsidianWatcher] Memantau vault: ${vaultPath}`);

    this.watcher = chokidar.watch(path.join(vaultPath, '**/*.md'), {
      ignored: [
        /(^|[/\\])\../,     // hidden files
        '**/Draft_AI/**',    // Draft_AI folder dikecualikan dari auto-sync
      ],
      persistent: true,
      ignoreInitial: false, // sync semua file saat server pertama kali start
      awaitWriteFinish: {
        stabilityThreshold: 500,
        pollInterval: 100,
      },
    });

    this.watcher
      .on('add', (filePath) => this.scheduleSync(filePath, 'add'))
      .on('change', (filePath) => this.scheduleSync(filePath, 'change'))
      .on('unlink', (filePath) => this.scheduleDelete(filePath))
      .on('error', (err) => logger.error('[ObsidianWatcher] Watcher error', err))
      .on('ready', () => {
        this.stats.isWatching = true;
        logger.info('[ObsidianWatcher] Initial scan selesai — siap memantau perubahan');
      });
  }

  async stop(): Promise<void> {
    if (this.watcher) {
      await this.watcher.close();
      this.watcher = null;
      this.stats.isWatching = false;
      logger.info('[ObsidianWatcher] Watcher dihentikan');
    }
  }

  getStats(): SyncStats {
    return { ...this.stats };
  }

  /**
   * Full resync: scan semua file .md di vault dan upsert ke DB.
   * Dipanggil via POST /api/sync/obsidian untuk manual trigger.
   */
  async fullResync(businessId: string): Promise<{ synced: number; skipped: number; errors: number }> {
    const vaultPath = env.OBSIDIAN_CS_PATH;
    if (!vaultPath) return { synced: 0, skipped: 0, errors: 0 };

    const result = { synced: 0, skipped: 0, errors: 0 };
    const files = await this.globMarkdownFiles(vaultPath);

    for (const filePath of files) {
      // Skip Draft_AI folder
      if (filePath.includes('Draft_AI')) { result.skipped++; continue; }

      try {
        await this.syncFile(filePath, businessId);
        result.synced++;
      } catch (err) {
        logger.error(`[ObsidianWatcher] Error resync file ${filePath}`, err);
        result.errors++;
      }
    }

    this.stats.lastSyncAt = new Date();
    logger.info(`[ObsidianWatcher] Full resync selesai: ${result.synced} synced, ${result.skipped} skipped, ${result.errors} errors`);
    return result;
  }

  // ─── Private Helpers ────────────────────────────────────────────────────────

  /** Debounce sync — hindari proses berulang jika file ditulis cepat */
  private scheduleSync(filePath: string, event: 'add' | 'change'): void {
    const debouncems = env.OBSIDIAN_WATCHER_DEBOUNCE_MS ?? 2000;

    if (this.debounceMap.has(filePath)) {
      clearTimeout(this.debounceMap.get(filePath)!);
    }

    const timer = setTimeout(async () => {
      this.debounceMap.delete(filePath);

      // Draft_AI: skip auto-sync
      if (filePath.includes('Draft_AI')) return;

      try {
        // Untuk watcher global, gunakan semua business — cari defaultnya
        await this.syncFileForAllBusinesses(filePath, event);
      } catch (err) {
        logger.error(`[ObsidianWatcher] Gagal sync file ${filePath}`, err);
      }
    }, debouncems);

    this.debounceMap.set(filePath, timer);
  }

  private scheduleDelete(filePath: string): void {
    const debouncems = env.OBSIDIAN_WATCHER_DEBOUNCE_MS ?? 2000;
    const timer = setTimeout(async () => {
      this.debounceMap.delete(filePath);
      try {
        const deleted = await prisma.knowledge.deleteMany({
          where: { sourceFile: filePath },
        });
        if (deleted.count > 0) {
          this.stats.totalDeleted += deleted.count;
          logger.info(`[ObsidianWatcher] File dihapus dari DB: ${path.basename(filePath)} (${deleted.count} record)`);
        }
      } catch (err) {
        logger.error(`[ObsidianWatcher] Gagal hapus record untuk ${filePath}`, err);
      }
    }, debouncems);
    this.debounceMap.set(`del:${filePath}`, timer);
  }

  /**
   * Sync satu file .md ke semua Business yang aktif.
   * Untuk multi-tenant: tiap business punya knowledge-nya sendiri di vault yang sama.
   * Jika vault dikunci 1:1 dengan business, semua business akan punya copy yang sama.
   */
  private async syncFileForAllBusinesses(filePath: string, event: string): Promise<void> {
    const businesses = await prisma.business.findMany({
      where: { isActive: true },
      select: { id: true },
    });

    if (businesses.length === 0) {
      logger.warn('[ObsidianWatcher] Tidak ada business aktif — skip sync');
      return;
    }

    for (const biz of businesses) {
      await this.syncFile(filePath, biz.id);
    }

    this.stats.totalSynced++;
    this.stats.lastSyncAt = new Date();
    logger.info(`[ObsidianWatcher] [${event}] Synced: ${path.basename(filePath)} → ${businesses.length} business(es)`);
  }

  /**
   * Core sync logic: baca file .md → parse frontmatter → generate embedding → upsert DB
   */
  private async syncFile(filePath: string, businessId: string): Promise<void> {
    const rawContent = await fs.readFile(filePath, 'utf-8');

    // Parse YAML frontmatter dengan gray-matter
    const { data: frontmatter, content: bodyContent } = matter(rawContent);

    // Tentukan judul: dari frontmatter.title, atau dari nama file
    const title =
      (typeof frontmatter.title === 'string' && frontmatter.title.trim()) ||
      path.basename(filePath, '.md').replace(/-/g, ' ');

    // Konten yang di-embed: gabungkan judul + body (frontmatter dibuang dari konten)
    const textToEmbed = `${title}\n\n${bodyContent.trim()}`;
    if (!textToEmbed.trim()) return; // skip file kosong

    const embedding = await knowledgeService.getEmbedding(textToEmbed);
    const vectorString = `[${embedding.join(',')}]`;
    const now = new Date();

    // Upsert: update jika sourceFile sudah ada untuk businessId ini
    const existing = await prisma.knowledge.findFirst({
      where: { businessId, sourceFile: filePath },
      select: { id: true },
    });

    if (existing) {
      await prisma.$executeRawUnsafe(
        `UPDATE knowledge
         SET title = $1, content = $2, embedding = $3::vector, synced_at = $4, updated_at = $4
         WHERE id = $5::uuid`,
        title,
        textToEmbed,
        vectorString,
        now,
        existing.id,
      );
    } else {
      await prisma.$executeRawUnsafe(
        `INSERT INTO knowledge (id, business_id, title, content, embedding, source_file, synced_at, created_at, updated_at)
         VALUES (gen_random_uuid(), $1::uuid, $2, $3, $4::vector, $5, $6, $6, $6)`,
        businessId,
        title,
        textToEmbed,
        vectorString,
        filePath,
        now,
      );
    }
  }

  /** Glob semua file .md secara rekursif di dalam folder vault */
  private async globMarkdownFiles(dir: string): Promise<string[]> {
    const results: string[] = [];
    const entries = await fs.readdir(dir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        const sub = await this.globMarkdownFiles(fullPath);
        results.push(...sub);
      } else if (entry.isFile() && entry.name.endsWith('.md')) {
        results.push(fullPath);
      }
    }
    return results;
  }
}

export const obsidianWatcher = new ObsidianWatcherService();
