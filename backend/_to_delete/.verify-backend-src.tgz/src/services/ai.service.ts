import Groq from 'groq-sdk';
import { env } from '../config/env';
import { prisma } from '../config/prisma';
import { logger } from '../utils/logger';
import {
  CONSECUTIVE_LIMIT,
  getConsecutiveCount,
  incrementConsecutive,
  isReplyRateLimited,
  markReplied,
} from './state.service';

const groq = new Groq({ apiKey: env.GROQ_API_KEY });

const CONTEXT_LIMIT = 20;
const DAILY_CAP = env.GROQ_DAILY_CAP_PER_LEAD;

// ── Fix audit A5: state rate limit & counter beruntun sudah pindah ke Redis ──
// Dulu dua Map in-memory (lastReplyTimestamps, consecutiveReplies) plus
// setInterval pembersih tiap 1 jam. Sekarang semuanya di state.service.ts:
// key Redis ber-TTL, jadi konsisten lintas instance dan tidak bocor memori.
// Perilaku "reset per jam" dari fix A7 dipertahankan lewat TTL fixed-window.

function getSystemPrompt(businessName: string): string {
  return `Kamu adalah AI Customer Service untuk ${businessName}. 
Gunakan bahasa Indonesia yang sopan dan profesional. 
Jawab pertanyaan pelanggan dengan ramah dan membantu.
Jika pelanggan ingin berbicara dengan sales, katakan akan segera dialihkan.
Jangan pernah mengaku sebagai manusia. Kamu adalah AI assistant.`;
}

export async function generateReply(
  businessId: string,
  leadId: string,
  messageText: string,
  leadName: string | null,
  businessName: string
): Promise<string | null> {
  if (await isReplyRateLimited(leadId)) {
    logger.warn(`Rate limit hit for lead ${leadId}`);
    return null;
  }

  const consCount = await getConsecutiveCount(leadId);
  if (consCount >= CONSECUTIVE_LIMIT) {
    logger.warn(`Consecutive reply limit hit for lead ${leadId}`);
    return null;
  }

  const lead = await prisma.lead.findUnique({ where: { id: leadId } });
  if (!lead) return null;
  if (lead.dailyAiCount >= DAILY_CAP) {
    logger.warn(`Daily AI cap reached for lead ${leadId}`);
    return null;
  }

  // Fix C5: leadId sudah didenormalisasi ke tabel messages, jadi konteks bisa
  // diambil tanpa JOIN ke conversations (pakai index [businessId, leadId, createdAt]).
  const recentMessages = await prisma.message.findMany({
    where: { businessId, leadId },
    orderBy: { createdAt: 'desc' },
    take: CONTEXT_LIMIT,
    select: { message: true, fromRole: true },
  });

  const contextMessages = recentMessages
    .reverse()
    .map(m => `${m.fromRole === 'LEAD' ? 'Pelanggan' : 'AI'}: ${m.message}`)
    .join('\n');

  const userName = leadName || 'Pelanggan';

  let knowledgeContext = '';
  try {
    const { knowledgeService } = await import('./knowledge.service');
    const retrievedDocs = await knowledgeService.searchRelevantKnowledge(businessId, messageText, 3);
    knowledgeContext = retrievedDocs.length > 0 
      ? `\n\nPengetahuan Bisnis Tambahan:\n${retrievedDocs.join('\n---\n')}\nGunakan informasi di atas untuk menjawab pertanyaan pelanggan jika relevan.` 
      : '';

    const completion = await groq.chat.completions.create({
      messages: [
        { role: 'system', content: getSystemPrompt(businessName) + knowledgeContext },
        { role: 'system', content: `Konteks percakapan:\n${contextMessages}` },
        { role: 'user', content: `${userName}: ${messageText}` },
      ],
      model: env.GROQ_MODEL,
      max_tokens: env.GROQ_MAX_TOKENS,
      temperature: env.GROQ_TEMPERATURE,
    });

    const reply = completion.choices[0]?.message?.content;
    if (!reply || reply.trim().length === 0) {
      return fallbackReply();
    }

    await markReplied(leadId);
    await incrementConsecutive(leadId);

    // ── NOTE (audit A1): dailyAiCount TIDAK di-increment di sini ──────────────
    // Sudah di-increment di message.service.ts:enqueueAiReply() sebelum job masuk
    // queue. Jika di-increment lagi di sini → double-count (+2 per reply).
    // Increment hanya di message.service.ts, bukan di sini.
    // ──────────────────────────────────────────────────────────────────────────

    return reply.trim();
  } catch (error: any) {
    logger.error(`Groq API error: ${error.message}`);

    try {
      const fallbackCompletion = await groq.chat.completions.create({
        messages: [
          { role: 'system', content: getSystemPrompt(businessName) + (typeof knowledgeContext !== 'undefined' ? knowledgeContext : '') },
          { role: 'user', content: `${userName}: ${messageText}` },
        ],
        model: env.GROQ_FALLBACK_MODEL,
        max_tokens: env.GROQ_MAX_TOKENS,
        temperature: env.GROQ_TEMPERATURE,
      });
      const reply = fallbackCompletion.choices[0]?.message?.content;
      return reply?.trim() || fallbackReply();
    } catch {
      return fallbackReply();
    }
  }
}

function fallbackReply(): string {
  return 'Maaf sedang sibuk, akan dijawab sales kami segera.';
}

export async function detectIntent(_businessId: string, _leadId: string, messageText: string): Promise<{
  intent: string;
  score: number;
}> {
  try {
    const completion = await groq.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: `Klasifikasikan intent pesan customer berikut ke dalam satu kategori: minat, tanya_harga, komplain, spam, atau unknown. Berikan skor 0-100 berdasarkan engagement. Respon dalam format JSON: {"intent": "kategori", "score": angka}`,
        },
        { role: 'user', content: messageText },
      ],
      model: env.GROQ_MODEL,
      max_tokens: 100,
      temperature: 0.3,
      response_format: { type: 'json_object' }, // Fix B2: paksa JSON agar JSON.parse tidak crash
    });

    const content = completion.choices[0]?.message?.content || '{}';
    let parsed: { intent?: string; score?: number } = {};
    try { parsed = JSON.parse(content); } catch { /* fallback ke default */ }

    return {
      intent: parsed.intent || 'unknown',
      score: Math.min(100, Math.max(0, Number(parsed.score) || 0)),
    };
  } catch {
    return { intent: 'unknown', score: 0 };
  }
}
