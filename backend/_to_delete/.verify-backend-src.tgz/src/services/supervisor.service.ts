/**
 * Supervisor Layer — Anti-Halusinasi SalesPintar v2.0
 *
 * Arsitektur: berdasarkan konsep Hermes AI (MreRes) + Umikha repo
 *
 * Alur:
 * 1. AI generateReply() menghasilkan draft jawaban
 * 2. supervisor.validate(draft, context) → risk score
 * 3. Jika risk RENDAH → kirim langsung
 * 4. Jika risk TINGGI → ganti dengan safe fallback + trigger handover admin
 *
 * Yang divalidasi:
 * - Klaim harga spesifik (angka Rp / nominal)
 * - Klaim stok ("ready", "tersedia", "ada")
 * - Klaim timeline ("besok", "2 hari", "hari ini")
 * - Janji komitmen ("kami jamin", "pasti", "garansi X")
 * - Hallucination pattern (jawaban bertentangan dengan knowledge base)
 */

import Groq from 'groq-sdk';
import { env } from '../config/env';
import { logger } from '../utils/logger';
import { knowledgeService } from './knowledge.service';

const groq = new Groq({ apiKey: env.GROQ_API_KEY });

// ─── Risk Level ───────────────────────────────────────────────────────────────
export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH';

export interface SupervisorResult {
  approved: boolean;
  riskLevel: RiskLevel;
  riskScore: number;        // 0–100
  riskReasons: string[];
  finalReply: string;       // reply yang aman dikirim
  triggeredHandover: boolean;
}

// ─── Pattern detectors (cepat, tanpa LLM) ────────────────────────────────────
const PRICE_PATTERN = /Rp\.?\s*[\d,.]+|[\d,.]+\s*ribu|[\d,.]+\s*juta/i;
const STOCK_PATTERN = /\b(ready|ready stok|ada stok|tersedia|masih ada|masih ready|in stock)\b/i;
const TIMELINE_PATTERN = /\b(hari ini|besok|lusa|2 hari|3 hari|minggu ini|langsung kirim|same day)\b/i;
const COMMITMENT_PATTERN = /\b(kami jamin|pasti|dijamin|100%|garansi sampai|bisa sampai|dijanjikan)\b/i;

function hasRiskyPattern(text: string): { patterns: string[]; baseScore: number } {
  const found: string[] = [];
  let score = 0;
  if (PRICE_PATTERN.test(text)) { found.push('klaim_harga'); score += 30; }
  if (STOCK_PATTERN.test(text)) { found.push('klaim_stok'); score += 25; }
  if (TIMELINE_PATTERN.test(text)) { found.push('klaim_timeline'); score += 20; }
  if (COMMITMENT_PATTERN.test(text)) { found.push('klaim_komitmen'); score += 25; }
  return { patterns: found, baseScore: Math.min(score, 100) };
}

// ─── LLM Validator (hanya jika pattern score > 0) ────────────────────────────
async function validateWithLLM(
  draftReply: string,
  userMessage: string,
  knowledgeContext: string,
): Promise<{ score: number; reasons: string[] }> {
  try {
    const resp = await groq.chat.completions.create({
      model: env.GROQ_MODEL, // model cepat cukup untuk validasi
      max_tokens: 200,
      temperature: 0,
      response_format: { type: 'json_object' },
      messages: [
        {
          role: 'system',
          content: `Kamu adalah supervisor AI Customer Service. Tugasmu: validasi apakah jawaban AI berikut AMAN untuk dikirim ke pelanggan.

PENGETAHUAN RESMI BISNIS:
${knowledgeContext || '(tidak ada knowledge yang relevan ditemukan)'}

ATURAN VALIDASI:
1. Jika jawaban menyebut harga/nominal spesifik yang TIDAK ADA di pengetahuan bisnis → BERISIKO
2. Jika jawaban mengklaim stok tersedia tanpa konfirmasi di pengetahuan → BERISIKO
3. Jika jawaban memberi janji waktu pengiriman yang tidak tercantum → BERISIKO
4. Jika jawaban bertentangan dengan informasi di pengetahuan bisnis → BERISIKO
5. Jika jawaban hanya menjelaskan secara umum tanpa klaim spesifik → AMAN

Output JSON: {"risk_score": 0-100, "reasons": ["alasan1", "alasan2"]}
risk_score 0 = sangat aman, 100 = sangat berisiko`,
        },
        {
          role: 'user',
          content: `Pesan pelanggan: "${userMessage}"\n\nJawaban AI yang akan dikirim: "${draftReply}"`,
        },
      ],
    });

    const raw = resp.choices[0]?.message?.content || '{}';
    const parsed = JSON.parse(raw);
    return {
      score: Math.min(100, Math.max(0, Number(parsed.risk_score) || 0)),
      reasons: Array.isArray(parsed.reasons) ? parsed.reasons : [],
    };
  } catch (err) {
    logger.warn(`[Supervisor] LLM validation failed, skipping: ${err}`);
    return { score: 0, reasons: [] };
  }
}

// ─── Safe Fallback Messages ───────────────────────────────────────────────────
const SAFE_FALLBACKS = [
  'Halo Kak! 😊 Untuk pertanyaan ini saya perlu konfirmasi dulu ke tim kami ya, biar infonya akurat. Tunggu sebentar atau ketik *0* untuk langsung chat dengan CS kami!',
  'Makasih sudah tanya Kak! 🙏 Pertanyaan ini butuh pengecekan lebih lanjut dari tim kami. Kami akan segera follow up. Atau ketik *0* untuk terhubung langsung!',
  'Hai Kak! Info yang ditanya butuh konfirmasi dari tim dulu nih, biar nggak salah kasih info. Sebentar ya! Atau ketik *0* kalau mau langsung chat dengan CS 😊',
];

function getSafeFallback(): string {
  return SAFE_FALLBACKS[Math.floor(Math.random() * SAFE_FALLBACKS.length)]!;
}

// ─── Main Supervisor Validate ─────────────────────────────────────────────────
export async function supervisorValidate(
  businessId: string,
  draftReply: string,
  userMessage: string,
  conversationId: string,
): Promise<SupervisorResult> {
  // Step 1: pattern check (cepat, tanpa LLM)
  const { patterns, baseScore } = hasRiskyPattern(draftReply);

  let finalScore = baseScore;
  let allReasons = [...patterns];

  // Step 2: LLM validation (hanya jika ada pattern berisiko)
  if (baseScore > 0) {
    let knowledgeContext = '';
    try {
      const docs = await knowledgeService.searchRelevantKnowledge(businessId, userMessage, 3);
      knowledgeContext = docs.join('\n---\n');
    } catch { /* knowledge tidak tersedia */ }

    const { score: llmScore, reasons: llmReasons } = await validateWithLLM(
      draftReply, userMessage, knowledgeContext,
    );

    // Gabung score: pattern + LLM, ambil yang lebih tinggi sebagai anchor
    finalScore = Math.max(baseScore, Math.round((baseScore + llmScore) / 2));
    allReasons = [...new Set([...patterns, ...llmReasons])];
  }

  // Step 3: tentukan risk level & keputusan
  const riskLevel: RiskLevel = finalScore >= 60 ? 'HIGH' : finalScore >= 30 ? 'MEDIUM' : 'LOW';
  const approved = riskLevel !== 'HIGH';
  const triggeredHandover = riskLevel === 'HIGH';
  const finalReply = approved ? draftReply : getSafeFallback();

  logger.info(
    `[Supervisor] conv:${conversationId} | score:${finalScore} | level:${riskLevel} | approved:${approved}` +
    (allReasons.length ? ` | reasons:[${allReasons.join(', ')}]` : ''),
  );

  return {
    approved,
    riskLevel,
    riskScore: finalScore,
    riskReasons: allReasons,
    finalReply,
    triggeredHandover,
  };
}
