import { Job } from 'bullmq';
import { prisma } from '../config/prisma';
import { baileysManager } from '../services/baileys.service';
import { generateReply } from '../services/ai.service';
import { supervisorValidate } from '../services/supervisor.service';
import { waSendQueue, aiTaggingQueue } from './index';
import { logger } from '../utils/logger';
import { getIO } from '../websocket/handler';

interface AiReplyJob {
  businessId: string;
  conversationId: string;
  leadId: string;
  messageText: string;
  leadName: string | null;
  waJid: string;
}

export async function handleAiReply(job: Job<AiReplyJob>) {
  const { businessId, conversationId, leadId, messageText, leadName, waJid } = job.data;

  const conversation = await prisma.conversation.findUnique({
    where: { id: conversationId },
  });

  if (!conversation || conversation.status !== 'AI') {
    logger.info(`Skipping AI reply for conversation ${conversationId}: status is ${conversation?.status}`);
    return;
  }

  const business = await prisma.business.findUnique({ where: { id: businessId } });
  if (!business) return;

  // ── Step 1: Generate draft reply dari AI ─────────────────────────────────
  const draftReply = await generateReply(
    businessId,
    leadId,
    messageText,
    leadName,
    business.name,
  );

  if (!draftReply) return;

  // ── Step 2: Supervisor validate sebelum kirim ─────────────────────────────
  const supervisorResult = await supervisorValidate(
    businessId,
    draftReply,
    messageText,
    conversationId,
  );

  const { finalReply, riskLevel, riskScore, riskReasons, triggeredHandover } = supervisorResult;

  // ── Step 3: Simpan reply ke DB (dengan metadata supervisor) ──────────────
  await prisma.message.create({
    data: {
      businessId,
      conversationId,
      leadId, // Fix C5: denormalisasi leadId supaya query konteks AI tak perlu JOIN
      message: finalReply,
      messageType: 'text',
      fromRole: 'AI',
      aiModel: `llama-3.1-8b|supervisor:${riskLevel}`,
      metadata: {
        supervisorRiskScore: riskScore,
        supervisorRiskLevel: riskLevel,
        supervisorRiskReasons: riskReasons,
        supervisorApproved: supervisorResult.approved,
        originalReplyBlocked: !supervisorResult.approved,
      },
    },
  });

  // ── Step 4: Kirim reply via WA ────────────────────────────────────────────
  await waSendQueue.add('send-ai-reply', {
    businessId,
    waJid,
    message: finalReply,
    priority: 'HIGH',
    typing: true,
  });

  // ── Step 5: Notify dashboard ──────────────────────────────────────────────
  const io = getIO();
  if (io) {
    io.to(`business:${businessId}`).emit('chat:new', {
      conversationId,
      message: { fromRole: 'AI', message: finalReply, createdAt: new Date() },
    });

    // Jika supervisor menolak reply asli → kirim alert ke dashboard
    if (!supervisorResult.approved) {
      io.to(`business:${businessId}`).emit('supervisor:alert', {
        conversationId,
        leadId,
        riskLevel,
        riskScore,
        riskReasons,
        blockedReply: draftReply.slice(0, 120) + '...', // preview saja, tidak kirim ke lead
        timestamp: new Date().toISOString(),
      });
    }
  }

  // ── Step 6: Auto-handover jika HIGH risk ─────────────────────────────────
  if (triggeredHandover) {
    logger.warn(`[Supervisor] HIGH risk — auto-handover conv ${conversationId} (score: ${riskScore})`);

    await prisma.conversation.update({
      where: { id: conversationId },
      data: { status: 'HUMAN' },
    });

    if (io) {
      io.to(`business:${businessId}`).emit('chat:handover', {
        conversationId,
        leadId,
        reason: 'supervisor_high_risk',
        riskScore,
        riskReasons,
      });
      io.to(`business:${businessId}`).emit('chat:status', {
        conversationId,
        status: 'HUMAN',
      });
    }
  }

  // ── Step 7: Tag lead (background) ────────────────────────────────────────
  await aiTaggingQueue.add('tag-lead', {
    businessId,
    leadId,
    messageText,
  }, { priority: 1 });

  logger.info(
    `[AiReply] conv:${conversationId} | risk:${riskLevel}(${riskScore}) | approved:${supervisorResult.approved}`,
  );
}
