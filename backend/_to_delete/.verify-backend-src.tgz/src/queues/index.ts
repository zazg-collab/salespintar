import { Queue, Worker, QueueEvents } from 'bullmq';
import { redisBull } from '../config/redis';
import { env } from '../config/env';
import { logger } from '../utils/logger';

export const aiReplyQueue = new Queue('ai-reply', {
  connection: redisBull,
  defaultJobOptions: {
    attempts: 3,
    backoff: { type: 'exponential', delay: 2000 },
    removeOnComplete: 100,
    removeOnFail: 50,
  },
});

export const aiTaggingQueue = new Queue('ai-tagging', {
  connection: redisBull,
  defaultJobOptions: {
    attempts: 2,
    backoff: { type: 'fixed', delay: 5000 },
    removeOnComplete: 100,
    removeOnFail: 50,
  },
});

export const waSendQueue = new Queue('wa-send', {
  connection: redisBull,
  defaultJobOptions: {
    attempts: 3,
    backoff: { type: 'exponential', delay: 3000 },
    removeOnComplete: 100,
    removeOnFail: 50,
  },
});

export const broadcastQueue = new Queue('broadcast', {
  connection: redisBull,
  defaultJobOptions: {
    attempts: 2,
    backoff: { type: 'fixed', delay: 10000 },
    removeOnComplete: 10,
    removeOnFail: 10,
  },
});

export { shadowMiningQueue } from './shadow-mining.queue';
// Fix A5: antrian flush debounce — pengganti setTimeout in-memory di message.service.ts
export { debounceQueue } from './debounce.queue';

export const aiReplyQueueEvents = new QueueEvents('ai-reply', { connection: redisBull });
export const broadcastQueueEvents = new QueueEvents('broadcast', { connection: redisBull });

export async function setupWorkers() {
  const { handleAiReply } = await import('./ai-reply.worker');
  const { handleBroadcast } = await import('./broadcast.worker');
  const { handleAiTagging } = await import('./tagging.worker');
  const { handleWaSend } = await import('./wa-send.worker');
  const { handleShadowMining } = await import('./shadow-mining.worker');
  const { handleDebounceFlush } = await import('./debounce.worker');

  new Worker('ai-reply', handleAiReply, {
    connection: redisBull,
    concurrency: 5,
  });

  new Worker('ai-tagging', handleAiTagging, {
    connection: redisBull,
    concurrency: 2,
  });

  new Worker('wa-send', handleWaSend, {
    connection: redisBull,
    concurrency: 3,
  });

  new Worker('broadcast', handleBroadcast, {
    connection: redisBull,
    concurrency: 1,
  });

  // Shadow Mining worker: concurrency 1 (operasi berat, hindari flood Groq API)
  new Worker('shadow-mining', handleShadowMining, {
    connection: redisBull,
    concurrency: 1,
    limiter: { max: 5, duration: 60000 }, // maks 5 job per menit
  });

  // Fix A5: worker penutup window debounce. Concurrency 5 karena tugasnya ringan
  // (satu operasi Redis + enqueue); yang berat tetap di worker ai-reply.
  new Worker('debounce-flush', handleDebounceFlush, {
    connection: redisBull,
    concurrency: 5,
  });

  logger.info('BullMQ workers initialized (including Shadow Mining & Debounce)');
}

export async function closeQueues() {
  const { shadowMiningQueue: smq } = await import('./shadow-mining.queue');
  const { debounceQueue: dq } = await import('./debounce.queue');
  await aiReplyQueue.close();
  await aiTaggingQueue.close();
  await waSendQueue.close();
  await broadcastQueue.close();
  await smq.close();
  await dq.close();
}
