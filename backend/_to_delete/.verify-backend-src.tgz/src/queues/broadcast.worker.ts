import { Job } from 'bullmq';
import { prisma } from '../config/prisma';
import { baileysManager } from '../services/baileys.service';
import { logger } from '../utils/logger';
import { getIO } from '../websocket/handler';
import { env } from '../config/env';

interface BroadcastJob {
  broadcastId: string;
  businessId: string;
}

export async function handleBroadcast(job: Job<BroadcastJob>) {
  const { broadcastId, businessId } = job.data;

  const broadcast = await prisma.broadcast.findUnique({
    where: { id: broadcastId },
    include: { business: true },
  });

  if (!broadcast || broadcast.status === 'CANCELLED') {
    logger.info(`Broadcast ${broadcastId} skipped or cancelled`);
    return;
  }

  // ── Fix B9: pastikan WA benar-benar tersambung SEBELUM mulai iterasi lead ──
  // Tanpa ini, broadcast ke ribuan lead bisa jalan saat WA putus: sebagian kecil
  // terkirim, sisanya gagal satu per satu, dan status akhirnya jadi PARTIAL yang
  // menyesatkan. Lebih baik berhenti di depan supaya broadcast bisa diulang utuh.
  if (!baileysManager.isConnected(businessId)) {
    logger.warn(`Broadcast ${broadcastId} dibatalkan: WhatsApp tidak tersambung untuk business ${businessId}`);

    await prisma.broadcast.update({
      where: { id: broadcastId },
      data: { status: 'PENDING' },
    });

    const ioDisc = getIO();
    if (ioDisc) {
      ioDisc.to(`business:${businessId}`).emit('broadcast:progress', {
        broadcastId,
        sent: 0,
        failed: 0,
        total: 0,
        status: 'PENDING',
        error: 'WhatsApp tidak tersambung — broadcast ditunda, silakan sambungkan WA lalu jalankan ulang.',
      });
    }

    // Lempar error supaya BullMQ mencatat & me-retry sesuai backoff antrian
    // (broadcast queue: 2 attempts, fixed delay 10 detik).
    throw new Error(`WhatsApp not connected for business ${businessId}`);
  }

  await prisma.broadcast.update({
    where: { id: broadcastId },
    data: { status: 'SENDING' },
  });

  // ── Fix A2: Whitelist filter fields — JANGAN spread user input ke Prisma WHERE ──────────
  interface SafeBroadcastFilter {
    segments?: string[];
    status?: string;
    lastChatDays?: number;
  }
  const rawFilter = (broadcast.filter ?? null) as SafeBroadcastFilter | null;
  const leadWhere: {
    businessId: string;
    status: string;
    segment?: { in: string[] };
    lastMessageAt?: { gte: Date };
  } = { businessId, status: 'ACTIVE' };

  if (rawFilter?.status && typeof rawFilter.status === 'string') {
    leadWhere.status = rawFilter.status;
  }
  if (Array.isArray(rawFilter?.segments) && rawFilter!.segments.length > 0) {
    leadWhere.segment = { in: rawFilter!.segments.filter(s => typeof s === 'string') };
  }
  if (typeof rawFilter?.lastChatDays === 'number' && rawFilter.lastChatDays > 0) {
    leadWhere.lastMessageAt = { gte: new Date(Date.now() - rawFilter.lastChatDays * 86400000) };
  }
  // ───────────────────────────────────────────────────────────────────────────────────

  const leads = await prisma.lead.findMany({ where: leadWhere });

  await prisma.broadcast.update({
    where: { id: broadcastId },
    data: { totalTarget: leads.length },
  });

  const io = getIO();
  let sent = 0;
  let failed = 0;

  for (let i = 0; i < leads.length; i += env.BROADCAST_BATCH_SIZE) {
    const batch = leads.slice(i, i + env.BROADCAST_BATCH_SIZE);

    for (const lead of batch) {
      try {
        if (!lead.waId) continue;

        const personalizedMessage = broadcast.templateVars.length > 0
          ? replaceVariables(broadcast.message, lead, broadcast.templateVars)
          : broadcast.message;

        const waId = lead.waId.includes('@s.whatsapp.net')
          ? lead.waId
          : `${lead.waId}@s.whatsapp.net`;

        const result = await baileysManager.sendMessage(businessId, waId, {
          text: personalizedMessage,
        });

        await prisma.broadcastLog.create({
          data: {
            businessId,
            broadcastId,
            leadId: lead.id,
            waMessageId: result?.key?.id || null,
            status: 'SENT',
            sentAt: new Date(),
          },
        });
        sent++;
      } catch (error: any) {
        failed++;
        await prisma.broadcastLog.create({
          data: {
            businessId,
            broadcastId,
            leadId: lead.id,
            status: 'FAILED',
            errorMessage: error.message,
          },
        });
      }
    }

    await prisma.broadcast.update({
      where: { id: broadcastId },
      data: { totalSent: sent, totalFailed: failed },
    });

    if (io) {
      io.to(`business:${businessId}`).emit('broadcast:progress', {
        broadcastId,
        sent,
        failed,
        total: leads.length,
      });
    }

    if (i + env.BROADCAST_BATCH_SIZE < leads.length) {
      await new Promise(resolve => setTimeout(resolve, env.BROADCAST_THROTTLE_MS));
    }
  }

  const finalStatus = failed === 0 ? 'SENT' : failed === leads.length ? 'FAILED' : 'PARTIAL';

  await prisma.broadcast.update({
    where: { id: broadcastId },
    data: { status: finalStatus, totalSent: sent, totalFailed: failed },
  });

  if (io) {
    io.to(`business:${businessId}`).emit('broadcast:progress', {
      broadcastId,
      sent,
      failed,
      total: leads.length,
      status: finalStatus,
    });
  }

  logger.info(`Broadcast ${broadcastId} completed: ${sent} sent, ${failed} failed`);
}

function replaceVariables(template: string, lead: any, vars: string[]): string {
  let result = template;
  for (const v of vars) {
    const key = v.toLowerCase();
    const value = String(lead[key] || lead[key === 'nama' ? 'name' : key] || '');
    result = result.replace(new RegExp(`\\{\\{\\s*${v}\\s*\\}\\}`, 'gi'), value);
  }
  return result;
}
