import { Queue } from 'bullmq';
import { redisBull } from '../config/redis';

export const SHADOW_MINING_QUEUE_NAME = 'shadow-mining';

export interface ShadowMiningJobData {
  conversationId: string;
  businessId: string;
  triggeredBy: 'auto' | 'manual';
}

export type ShadowMiningResult =
  | { skipped: true; reason: 'too_few_messages' | 'no_knowledge_value' | 'extraction_failed' | 'duplicate_content' | 'already_mined' | 'conversation_not_found'; jobId: string }
  | { skipped: false; vaultPath: string; title: string; category: string; mode: string; jobId: string };

export const shadowMiningQueue = new Queue<ShadowMiningJobData>(SHADOW_MINING_QUEUE_NAME, {
  connection: redisBull,
  defaultJobOptions: {
    attempts: 2,
    backoff: { type: 'exponential', delay: 5000 },
    removeOnComplete: { count: 200 },
    removeOnFail: { count: 100 },
  },
});
