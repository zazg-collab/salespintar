import { Router, Request, Response, NextFunction } from 'express';
import { authenticate, authorize } from '../middleware/auth';
import { obsidianWatcher } from '../services/obsidian-watcher.service';
import { env } from '../config/env';
import fs from 'fs/promises';
import path from 'path';
import matter from 'gray-matter';

const router = Router();

// ─── Helper: pastikan path ada di dalam vault (security: no path traversal) ──
function safeVaultPath(relativePath: string): string | null {
  const vault = env.OBSIDIAN_CS_PATH;
  const resolved = path.resolve(vault, relativePath);
  if (!resolved.startsWith(path.resolve(vault))) return null; // path traversal attempt
  return resolved;
}

// ─── Helper: rekursif build file tree ────────────────────────────────────────
interface FileNode {
  name: string;
  path: string;
  type: 'file' | 'folder';
  children?: FileNode[];
  size?: number;
  syncedAt?: string | null;
  extension?: string;
}

async function buildFileTree(dir: string, vaultRoot: string): Promise<FileNode[]> {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  const nodes: FileNode[] = [];

  for (const entry of entries) {
    if (entry.name.startsWith('.')) continue; // skip hidden
    const fullPath = path.join(dir, entry.name);
    const relativePath = path.relative(vaultRoot, fullPath);

    if (entry.isDirectory()) {
      const children = await buildFileTree(fullPath, vaultRoot);
      nodes.push({ name: entry.name, path: relativePath, type: 'folder', children });
    } else {
      const stat = await fs.stat(fullPath);
      const ext = path.extname(entry.name).toLowerCase();
      nodes.push({
        name: entry.name,
        path: relativePath,
        type: 'file',
        size: stat.size,
        extension: ext,
      });
    }
  }

  // Sort: folders first, then files; alphabetically
  return nodes.sort((a, b) => {
    if (a.type !== b.type) return a.type === 'folder' ? -1 : 1;
    return a.name.localeCompare(b.name);
  });
}

// ──────────────────────────────────────────────────────────────────────────────
// Manual Sync Endpoints
// ──────────────────────────────────────────────────────────────────────────────

/**
 * POST /api/v1/sync/obsidian
 * Trigger full resync semua file .md di vault ke DB.
 */
router.post('/obsidian', authenticate, authorize('ADMIN'), async (req: Request, res: Response, next: NextFunction) => {
  try {
    const result = await obsidianWatcher.fullResync(req.user!.businessId);
    res.json({
      success: true,
      message: 'Resync selesai',
      data: result,
    });
  } catch (err) { next(err); }
});

/**
 * GET /api/v1/sync/status
 * Status watcher: aktif/tidak, total synced, last sync.
 */
router.get('/status', authenticate, async (_req: Request, res: Response, next: NextFunction) => {
  try {
    const stats = obsidianWatcher.getStats();
    res.json({
      success: true,
      data: {
        isWatching: stats.isWatching,
        vaultPath: stats.vaultPath || env.OBSIDIAN_CS_PATH,
        totalSynced: stats.totalSynced,
        totalDeleted: stats.totalDeleted,
        lastSyncAt: stats.lastSyncAt,
      },
    });
  } catch (err) { next(err); }
});

// ──────────────────────────────────────────────────────────────────────────────
// Vault File Explorer Endpoints
// ──────────────────────────────────────────────────────────────────────────────

/**
 * GET /api/v1/sync/vault/tree
 * Kembalikan tree struktur folder vault Obsidian CS Brain.
 */
router.get('/vault/tree', authenticate, async (_req: Request, res: Response, next: NextFunction) => {
  try {
    const vault = env.OBSIDIAN_CS_PATH;
    await fs.access(vault); // pastikan vault ada
    const tree = await buildFileTree(vault, vault);
    res.json({ success: true, data: { tree, vaultPath: vault } });
  } catch (err: any) {
    if (err.code === 'ENOENT') {
      res.json({ success: true, data: { tree: [], vaultPath: env.OBSIDIAN_CS_PATH } });
    } else { next(err); }
  }
});

/**
 * GET /api/v1/sync/vault/file?path=Produk/pisau.md
 * Baca isi satu file .md dari vault.
 */
router.get('/vault/file', authenticate, async (req: Request, res: Response, next: NextFunction) => {
  try {
    const relPath = req.query.path as string;
    if (!relPath) { res.status(400).json({ error: { message: 'Parameter path wajib diisi' } }); return; }

    const absPath = safeVaultPath(relPath);
    if (!absPath) { res.status(400).json({ error: { message: 'Path tidak valid' } }); return; }

    const raw = await fs.readFile(absPath, 'utf-8');
    const { data: frontmatter, content } = matter(raw);
    res.json({ success: true, data: { path: relPath, frontmatter, content, raw } });
  } catch (err: any) {
    if (err.code === 'ENOENT') { res.status(404).json({ error: { message: 'File tidak ditemukan' } }); }
    else { next(err); }
  }
});

/**
 * PUT /api/v1/sync/vault/file
 * Simpan/update isi file .md ke vault. Watcher akan otomatis re-embed.
 * Body: { path: "Produk/pisau.md", content: "# ..." }
 */
router.put('/vault/file', authenticate, authorize('ADMIN'), async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { path: relPath, content } = req.body as { path: string; content: string };
    if (!relPath || content === undefined) {
      res.status(400).json({ error: { message: 'path dan content wajib diisi' } }); return;
    }

    const absPath = safeVaultPath(relPath);
    if (!absPath) { res.status(400).json({ error: { message: 'Path tidak valid' } }); return; }

    // Buat folder parent jika belum ada
    await fs.mkdir(path.dirname(absPath), { recursive: true });
    await fs.writeFile(absPath, content, 'utf-8');

    res.json({ success: true, message: 'File disimpan. Watcher akan sync otomatis dalam beberapa detik.' });
  } catch (err) { next(err); }
});

/**
 * DELETE /api/v1/sync/vault/file?path=Produk/pisau.md
 * Hapus file .md dari vault. Watcher akan otomatis hapus dari DB.
 */
router.delete('/vault/file', authenticate, authorize('ADMIN'), async (req: Request, res: Response, next: NextFunction) => {
  try {
    const relPath = req.query.path as string;
    if (!relPath) { res.status(400).json({ error: { message: 'Parameter path wajib diisi' } }); return; }

    const absPath = safeVaultPath(relPath);
    if (!absPath) { res.status(400).json({ error: { message: 'Path tidak valid' } }); return; }

    await fs.unlink(absPath);
    res.json({ success: true, message: 'File dihapus dari vault.' });
  } catch (err: any) {
    if (err.code === 'ENOENT') { res.status(404).json({ error: { message: 'File tidak ditemukan' } }); }
    else { next(err); }
  }
});

/**
 * POST /api/v1/sync/vault/upload
 * Upload file .md langsung sebagai teks ke folder vault.
 * Body: { folder: "Produk", filename: "pisau.md", content: "# ..." }
 */
router.post('/vault/upload', authenticate, authorize('ADMIN'), async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { folder, filename, content } = req.body as { folder: string; filename: string; content: string };
    if (!folder || !filename || content === undefined) {
      res.status(400).json({ error: { message: 'folder, filename, dan content wajib diisi' } }); return;
    }

    // Validasi extension
    const ext = path.extname(filename).toLowerCase();
    if (ext !== '.md') {
      res.status(400).json({ error: { message: 'Hanya file .md yang diizinkan untuk upload langsung' } }); return;
    }

    const relPath = path.join(folder, filename);
    const absPath = safeVaultPath(relPath);
    if (!absPath) { res.status(400).json({ error: { message: 'Path tidak valid' } }); return; }

    await fs.mkdir(path.dirname(absPath), { recursive: true });
    await fs.writeFile(absPath, content, 'utf-8');

    res.status(201).json({
      success: true,
      message: 'File berhasil diupload ke vault. Bot akan belajar dari file ini secara otomatis.',
      data: { path: relPath },
    });
  } catch (err) { next(err); }
});

export default router;
