import { pipeline } from '@xenova/transformers';
import { prisma } from '../config/prisma';
import { env } from '../config/env';
import { logger } from '../utils/logger';

class KnowledgeService {
  private extractor: any = null;
  // Fix audit B8: dulu pakai flag boolean `isInitializing`. Dua pemanggil
  // konkuren bisa sama-sama lolos pengecekan sebelum flag sempat di-set, lalu
  // memuat model embedding dua kali (boros memori & CPU). Sekarang kita simpan
  // PROMISE-nya: pemanggil kedua menunggu promise yang sama, bukan memulai init
  // baru. Promise dibuang kalau gagal supaya percobaan berikutnya tetap bisa jalan.
  private initPromise: Promise<void> | null = null;

  async init(): Promise<void> {
    if (this.extractor) return;
    if (this.initPromise) return this.initPromise;

    this.initPromise = (async () => {
      // Model diambil dari env supaya bisa diganti tanpa menyentuh kode.
      // Bawaannya kini varian multibahasa: all-MiniLM-L6-v2 dilatih dominan
      // berbahasa Inggris, sehingga mencocokkan pertanyaan bahasa Indonesia
      // dengan dokumen bahasa Indonesia hasilnya pas-pasan. Kalau pencarian
      // mengambil dokumen yang salah, secanggih apa pun model chat-nya jawaban
      // tetap meleset — itu titik terlemah RAG di sistem ini.
      logger.info(`Initializing embedding model: ${env.EMBEDDING_MODEL}...`);
      const { pipeline: getPipeline } = await import('@xenova/transformers');
      this.extractor = await getPipeline('feature-extraction', env.EMBEDDING_MODEL);
      logger.info('Embedding model initialized successfully');
    })().catch((err) => {
      logger.error('Failed to initialize embedding model', err);
      // Reset supaya init bisa dicoba lagi nanti, bukan gagal permanen.
      this.initPromise = null;
      this.extractor = null;
    });

    return this.initPromise;
  }

  /**
   * Ubah teks jadi vektor.
   *
   * `kind` WAJIB diisi karena model E5 memperlakukan pertanyaan dan dokumen
   * secara berbeda — pertanyaan diberi awalan "query: ", dokumen "passage: ".
   * Ini bukan hiasan: tanpa awalan yang tepat, kualitas pencarian E5 justru
   * jatuh di bawah model biasa. Karena mudah terlupa, parameternya sengaja
   * dibuat wajib supaya setiap pemanggil harus menyatakan maksudnya.
   */
  async getEmbedding(text: string, kind: 'query' | 'passage'): Promise<number[]> {
    if (!this.extractor) await this.init();
    if (!this.extractor) throw new Error('Embedding model not available');

    const input = env.EMBEDDING_USE_E5_PREFIX ? `${kind}: ${text}` : text;
    const output = await this.extractor(input, { pooling: 'mean', normalize: true });
    const vector = Array.from(output.data) as number[];

    // Penjaga: kolom di database bertipe vector(384). Kalau model diganti ke
    // yang dimensinya lain, kegagalannya akan muncul jauh di hilir sebagai
    // error SQL yang membingungkan. Lebih baik berhenti di sini dengan pesan
    // yang menyebut angkanya.
    if (vector.length !== 384) {
      throw new Error(
        `Model embedding "${env.EMBEDDING_MODEL}" menghasilkan ${vector.length} dimensi, ` +
        `sedangkan kolom database bertipe vector(384). Ganti modelnya, atau ubah schema ` +
        `Prisma + buat migrasi untuk dimensi baru lalu embed ulang seluruh vault.`,
      );
    }
    return vector;
  }

  async addKnowledge(businessId: string, title: string, content: string) {
    // Generate embedding for the content
    // Dokumen yang disimpan → "passage"
    const embedding = await this.getEmbedding(content, 'passage');
    
    // Save to database with vector
    // Using parameterized query to safely inject the embedding
    const query = `
      INSERT INTO knowledge (id, business_id, title, content, embedding, created_at, updated_at)
      VALUES (gen_random_uuid(), $1::uuid, $2, $3, $4::vector, NOW(), NOW())
      RETURNING id
    `;
    
    // Format the array as a vector literal string e.g. '[0.1, 0.2, ...]'
    const vectorString = `[${embedding.join(',')}]`;
    
    await prisma.$executeRawUnsafe(
      query,
      businessId,
      title,
      content,
      vectorString
    );
    
    logger.info(`Knowledge added for business ${businessId}`);
  }

  async searchRelevantKnowledge(businessId: string, query: string, limit: number = 3): Promise<string[]> {
    try {
      // Pertanyaan pelanggan → "query"
      const embedding = await this.getEmbedding(query, 'query');
      const vectorString = `[${embedding.join(',')}]`;

      // Use cosine distance (<=>) for search
      // Return top matching chunks
      const results = await prisma.$queryRawUnsafe<any[]>(`
        SELECT content, 1 - (embedding <=> $2::vector) as similarity
        FROM knowledge
        WHERE business_id = $1::uuid
        ORDER BY embedding <=> $2::vector
        LIMIT $3
      `, businessId, vectorString, limit);

      // Filter by reasonable similarity threshold (e.g. > 0.3)
      return results
        .filter(r => r.similarity > 0.3)
        .map(r => r.content);
    } catch (err) {
      logger.error(`Error searching knowledge: ${err}`);
      return [];
    }
  }

  async listKnowledge(businessId: string) {
    return prisma.knowledge.findMany({
      where: { businessId },
      select: { id: true, title: true, createdAt: true, updatedAt: true },
      orderBy: { createdAt: 'desc' }
    });
  }

  async deleteKnowledge(id: string, businessId: string) {
    await prisma.knowledge.deleteMany({
      where: { id, businessId }
    });
  }
}

export const knowledgeService = new KnowledgeService();
