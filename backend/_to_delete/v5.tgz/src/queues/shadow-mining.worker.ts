import { Job } from 'bullmq';
import Groq from 'groq-sdk';
import fs from 'fs/promises';
import path from 'path';
import { prisma } from '../config/prisma';
import { logger } from '../utils/logger';
import { env } from '../config/env';
import { knowledgeService } from '../services/knowledge.service';
import type { ShadowMiningJobData, ShadowMiningResult } from './shadow-mining.queue';

const groq = new Groq({ apiKey: env.GROQ_API_KEY });

// ──────────────────────────────────────────────────────────────────────────────
// Layer 1: Spam/Value Detector — model cepat (Llama 8B)
// Output: true = ada knowledge, false = buang
// ──────────────────────────────────────────────────────────────────────────────
async function detectKnowledgeValue(conversationText: string): Promise<boolean> {
  const resp = await groq.chat.completions.create({
    model: env.GROQ_MODEL, // llama-3.1-8b-instant — cepat & murah
    max_tokens: 5,
    temperature: 0,
    messages: [
      {
        role: 'system',
        content: `Kamu adalah filter konten untuk sistem pembelajaran AI bisnis. 
Tentukan apakah percakapan CS berikut mengandung informasi bisnis yang bernilai untuk dipelajari AI.

BERNILAI → jawab YES jika ada:
- Info harga produk, promo, diskon spesifik
- Kebijakan pengiriman, retur, garansi
- SOP atau prosedur CS yang bisa distandarkan
- FAQ yang sering muncul beserta jawabannya
- Info produk/layanan yang detail dan spesifik

TIDAK BERNILAI → jawab NO jika hanya:
- Basa-basi (halo, terima kasih, oke, baik kak)
- Keluhan sesaat tanpa resolusi
- Nomor resi atau info pengiriman personal
- Spam atau chat tidak jelas
- Kurang dari 4 interaksi substantif

JAWAB HANYA dengan kata: YES atau NO`,
      },
      { role: 'user', content: `PERCAKAPAN:\n${conversationText}` },
    ],
  });

  const answer = (resp.choices[0]?.message?.content || 'NO').trim().toUpperCase();
  return answer.startsWith('YES');
}

// ──────────────────────────────────────────────────────────────────────────────
// Layer 2: Knowledge Extractor — model cerdas (Llama 70B)
// Output: dokumen terstruktur siap masuk vault
// ──────────────────────────────────────────────────────────────────────────────
export interface ExtractedKnowledge {
  title: string;
  category: 'Produk' | 'SOP' | 'FAQ';
  filename: string;
  content: string;
}

async function extractKnowledge(conversationText: string): Promise<ExtractedKnowledge | null> {
  const resp = await groq.chat.completions.create({
    model: env.GROQ_EXTRACTOR_MODEL, // llama-3.3-70b-versatile — cerdas untuk ekstraksi
    max_tokens: 2048,
    temperature: 0.2,
    response_format: { type: 'json_object' },
    messages: [
      {
        role: 'system',
        content: `Kamu adalah asisten ekstraksi pengetahuan untuk sistem AI Customer Service.
Tugasmu: ubah percakapan CS menjadi dokumen pengetahuan terstruktur dalam format JSON.

ATURAN WAJIB:
1. HAPUS SEMUA DATA PRIBADI: nama pelanggan spesifik, nomor HP, alamat, nomor resi/pesanan
2. Ganti data pribadi dengan placeholder: [NAMA_PELANGGAN], [NO_RESI], [ALAMAT], [NO_HP]
3. Fokus pada informasi UMUM yang bisa dipakai ulang untuk pelanggan lain
4. Tulis dalam Bahasa Indonesia profesional dan ramah
5. Jika konten tidak cukup untuk jadi knowledge → kembalikan null untuk semua field

FORMAT JSON OUTPUT WAJIB:
{
  "title": "Judul singkat deskriptif (maks 60 karakter)",
  "category": "FAQ" | "Produk" | "SOP",
  "filename": "nama-file-lowercase-tanpa-spasi",
  "content": "Konten lengkap Markdown di sini..."
}

FORMAT KONTEN MARKDOWN yang diharapkan:
# [Judul]

## Situasi / Pertanyaan
[Deskripsi situasi umum, TANPA data pribadi]

## Jawaban / Solusi
[Jawaban atau prosedur yang diberikan CS, terstruktur dan jelas]

## Catatan Penting
[Info tambahan yang relevan, jika ada]

Panduan category:
- FAQ: Pertanyaan yang sering muncul dari pelanggan + jawabannya
- Produk: Info spesifik tentang produk (harga, spec, ketersediaan, promo)  
- SOP: Prosedur operasional CS (cara handle komplain, alur retur, dll)`,
      },
      { role: 'user', content: `PERCAKAPAN CS:\n${conversationText}` },
    ],
  });

  try {
    const raw = resp.choices[0]?.message?.content || '{}';
    const parsed = JSON.parse(raw) as ExtractedKnowledge;
    if (!parsed.title || !parsed.content || !parsed.category) return null;

    // Sanitize filename: huruf kecil, hanya alfanumerik dan dash
    parsed.filename = parsed.filename
      .toLowerCase()
      .replace(/[^a-z0-9-]/g, '-')
      .replace(/-+/g, '-')
      .replace(/^-|-$/g, '');
    if (!parsed.filename) parsed.filename = 'pengetahuan-baru';

    return parsed;
  } catch (err) {
    logger.warn(`[ShadowMining] Layer 2 JSON parse error: ${err}`);
    return null;
  }
}

// ──────────────────────────────────────────────────────────────────────────────
// Layer 3: Anti-Duplikat — cek vector similarity
// Output: true = duplikat (skip), false = baru (lanjut)
// ──────────────────────────────────────────────────────────────────────────────
async function isDuplicate(businessId: string, content: string): Promise<boolean> {
  try {
    // Membandingkan calon dokumen baru dengan dokumen yang sudah tersimpan —
    // dua-duanya "passage", bukan pertanyaan.
    const embedding = await knowledgeService.getEmbedding(content.slice(0, 1000), 'passage'); // truncate for speed
    const vectorString = `[${embedding.join(',')}]`;
    const threshold = env.SHADOW_MINING_SIMILARITY_THRESHOLD;

    const results = await prisma.$queryRawUnsafe<{ similarity: number }[]>(`
      SELECT 1 - (embedding <=> $2::vector) AS similarity
      FROM knowledge
      WHERE business_id = $1::uuid AND embedding IS NOT NULL
      ORDER BY embedding <=> $2::vector
      LIMIT 1
    `, businessId, vectorString);

    if (results.length === 0) return false;
    const sim = Number(results[0].similarity);
    if (sim >= threshold) {
      logger.info(`[ShadowMining] Layer 3: duplicate found (similarity=${sim.toFixed(3)}, threshold=${threshold})`);
    }
    return sim >= threshold;
  } catch (err) {
    logger.warn(`[ShadowMining] Layer 3 similarity check failed (allowing creation): ${err}`);
    return false; // Jika gagal cek, tetap izinkan buat file baru
  }
}

// ──────────────────────────────────────────────────────────────────────────────
// Write to Vault — tulis .md ke Obsidian CS Brain
// ──────────────────────────────────────────────────────────────────────────────
async function writeToVault(
  businessId: string,
  extracted: ExtractedKnowledge,
  mode: 'auto' | 'draft',
  conversationId: string,
): Promise<string> {
  const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const folder = mode === 'auto' ? extracted.category : 'Draft_AI';
  const filename = `${dateStr}-${extracted.filename}.md`;
  const absPath = path.join(env.OBSIDIAN_CS_PATH, folder, filename);

  await fs.mkdir(path.dirname(absPath), { recursive: true });

  const frontmatter = [
    '---',
    `title: "${extracted.title}"`,
    `category: ${extracted.category}`,
    `source: shadow-mining`,
    `business_id: ${businessId}`,
    `conversation_id: ${conversationId}`,
    `mined_at: ${new Date().toISOString()}`,
    `status: ${mode === 'auto' ? 'active' : 'draft'}`,
    '---',
    '',
  ].join('\n');

  await fs.writeFile(absPath, frontmatter + extracted.content, 'utf-8');
  return `${folder}/${filename}`;
}

// ──────────────────────────────────────────────────────────────────────────────
// Resolusi mode Shadow Mining — Fix C9
// Sumber kebenaran ada di kolom Business.shadowMiningMode. Nilai null berarti
// business itu belum pernah mengubah setelan, jadi kita pakai default dari env.
// ──────────────────────────────────────────────────────────────────────────────
/**
 * Apakah penambangan otomatis (saat percakapan ditandai Selesai) diizinkan.
 *
 * Sebelumnya auto-trigger menyala permanen tanpa cara mematikannya: setiap
 * percakapan yang selesai langsung memakan token Groq. Toggle Auto/Draft yang
 * sudah ada hanya mengatur hasilnya mau ke mana, bukan apakah penambangannya
 * jalan. Kolom ini yang memberi remnya.
 */
export async function isAutoMiningEnabled(businessId: string): Promise<boolean> {
  const business = await prisma.business.findUnique({
    where: { id: businessId },
    select: { shadowMiningAutoTrigger: true },
  });
  return business?.shadowMiningAutoTrigger ?? true;
}

export async function resolveShadowMiningMode(businessId: string): Promise<'auto' | 'draft'> {
  const business = await prisma.business.findUnique({
    where: { id: businessId },
    select: { shadowMiningMode: true },
  });
  const mode = business?.shadowMiningMode ?? env.SHADOW_MINING_MODE;
  return mode === 'auto' ? 'auto' : 'draft';
}

// ──────────────────────────────────────────────────────────────────────────────
// Main Worker Handler
// ──────────────────────────────────────────────────────────────────────────────
export async function handleShadowMining(job: Job<ShadowMiningJobData>): Promise<ShadowMiningResult> {
  const { businessId, triggeredBy } = job.data;

  // ── Dua sumber bahan tambang ──────────────────────────────────────────────
  // Percakapan dari database, atau transkrip lepas hasil impor ekspor WhatsApp.
  // Setelah `conversationText` dan `sourceRef` terbentuk, SELURUH pipeline di
  // bawah identik — tiga lapis filter tidak perlu tahu asal bahannya.
  let conversationText: string;
  let sourceRef: string;
  let conversationIdForMark: string | null = null;

  if (job.data.kind === 'import') {
    sourceRef = job.data.sourceLabel;
    conversationText = job.data.rawTranscript;
    logger.info(`[ShadowMining] Start job ${job.id} — impor:${sourceRef} (by: ${triggeredBy})`);

    // Idempotency lewat `minedAt` tidak berlaku di sini: tidak ada baris
    // Conversation yang bisa ditandai. Perlindungan terhadap duplikat bersandar
    // pada Layer 3 (kemiripan vektor), yang memang dirancang untuk itu.
    const lineCount = conversationText.split('\n').filter(l => l.trim()).length;
    if (lineCount < env.SHADOW_MINING_MIN_MESSAGES) {
      logger.info(`[ShadowMining] SKIP impor ${sourceRef}: cuma ${lineCount} baris (min: ${env.SHADOW_MINING_MIN_MESSAGES})`);
      return { skipped: true, reason: 'too_few_messages', jobId: job.id! };
    }
  } else {
    const conversationId = job.data.conversationId;
    sourceRef = conversationId;
    conversationIdForMark = conversationId;
    logger.info(`[ShadowMining] Start job ${job.id} — conv:${conversationId} (by: ${triggeredBy})`);

    // ── Fix B4: Idempotency check ────────────────────────────────────────────
    // Satu percakapan bisa masuk antrian lebih dari sekali (auto-trigger saat
    // status DONE + trigger manual + trigger batch, plus retry BullMQ). Tanpa
    // penjaga ini, percakapan yang sama diproses berulang: boros token Groq dan
    // berpotensi menumpuk file duplikat di vault. `minedAt` diisi hanya kalau
    // mining benar-benar menghasilkan dokumen.
    const conversation = await prisma.conversation.findFirst({
      where: { id: conversationId, businessId },
      select: { id: true, minedAt: true },
    });

    if (!conversation) {
      logger.warn(`[ShadowMining] SKIP: conversation ${conversationId} tidak ditemukan untuk business ${businessId}`);
      return { skipped: true, reason: 'conversation_not_found', jobId: job.id! };
    }

    if (conversation.minedAt) {
      logger.info(`[ShadowMining] SKIP: conv ${conversationId} sudah pernah di-mine pada ${conversation.minedAt.toISOString()}`);
      return { skipped: true, reason: 'already_mined', jobId: job.id! };
    }

    const messages = await prisma.message.findMany({
      where: { conversationId, businessId },
      orderBy: { createdAt: 'asc' },
      select: { fromRole: true, message: true },
    });

    if (messages.length < env.SHADOW_MINING_MIN_MESSAGES) {
      logger.info(`[ShadowMining] SKIP: only ${messages.length} msgs (min: ${env.SHADOW_MINING_MIN_MESSAGES})`);
      return { skipped: true, reason: 'too_few_messages', jobId: job.id! };
    }

    conversationText = messages
      .map(m => `[${m.fromRole === 'AI' ? 'BOT' : m.fromRole}] ${m.message}`)
      .join('\n');
  }

  await job.updateProgress(15);

  // ── Layer 1: Deteksi nilai ──
  const hasValue = await detectKnowledgeValue(conversationText);
  if (!hasValue) {
    logger.info(`[ShadowMining] Layer 1 REJECTED — no knowledge value`);
    return { skipped: true, reason: 'no_knowledge_value', jobId: job.id! };
  }
  logger.info(`[ShadowMining] Layer 1 PASSED`);
  await job.updateProgress(40);

  // ── Layer 2: Ekstraksi ──
  const extracted = await extractKnowledge(conversationText);
  if (!extracted) {
    logger.warn(`[ShadowMining] Layer 2 FAILED — extraction returned null`);
    return { skipped: true, reason: 'extraction_failed', jobId: job.id! };
  }
  logger.info(`[ShadowMining] Layer 2 PASSED — "${extracted.title}" [${extracted.category}]`);
  await job.updateProgress(70);

  // ── Layer 3: Anti-duplikat ──
  const duplicate = await isDuplicate(businessId, extracted.content);
  if (duplicate) {
    logger.info(`[ShadowMining] Layer 3 REJECTED — duplicate content`);
    return { skipped: true, reason: 'duplicate_content', jobId: job.id! };
  }
  logger.info(`[ShadowMining] Layer 3 PASSED — no duplicate`);
  await job.updateProgress(85);

  // ── Tulis ke Vault ──
  // Fix C9: mode dibaca dari DB (per business), bukan dari objek env yang dulu
  // dimutasi saat runtime. env sekarang hanya jadi default kalau business belum
  // pernah menyetel modenya.
  const mode = await resolveShadowMiningMode(businessId);
  const vaultPath = await writeToVault(businessId, extracted, mode, sourceRef);
  logger.info(`[ShadowMining] Written to vault: ${vaultPath} (mode: ${mode})`);

  // Fix B4: tandai sudah di-mine supaya job berikutnya untuk percakapan ini di-skip.
  // Hanya berlaku untuk percakapan database — transkrip impor tidak punya baris
  // Conversation, dan perlindungan duplikatnya sudah dipegang Layer 3.
  if (conversationIdForMark) {
    await prisma.conversation.update({
      where: { id: conversationIdForMark },
      data: { minedAt: new Date() },
    });
  }

  await job.updateProgress(100);

  return {
    skipped: false,
    vaultPath,
    title: extracted.title,
    category: extracted.category,
    mode,
    jobId: job.id!,
  };
}
