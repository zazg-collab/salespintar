/**
 * Supervisor Layer — Anti-Halusinasi SalesPintar v2.0
 *
 * Arsitektur: berdasarkan konsep Hermes AI (MreRes) + Umikha repo
 *
 * Alur:
 * 1. AI generateReply() menghasilkan draft jawaban
 * 2. supervisor.validate(draft, context) → risk score
 * 3. Jika risk RENDAH → kirim langsung
 * 4. Jika risk TINGGI → ganti dengan safe fallback + trigger handover admin
 *
 * Yang divalidasi:
 * - Klaim harga spesifik (angka Rp / nominal)
 * - Klaim stok ("ready", "tersedia", "ada")
 * - Klaim timeline ("besok", "2 hari", "hari ini")
 * - Janji komitmen ("kami jamin", "pasti", "garansi X")
 * - Hallucination pattern (jawaban bertentangan dengan knowledge base)
 */

import Groq from 'groq-sdk';
import { env } from '../config/env';
import { logger } from '../utils/logger';
import { knowledgeService } from './knowledge.service';

const groq = new Groq({ apiKey: env.GROQ_API_KEY });

// ─── Risk Level ───────────────────────────────────────────────────────────────
export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH';

export interface SupervisorResult {
  approved: boolean;
  riskLevel: RiskLevel;
  riskScore: number;        // 0–100
  riskReasons: string[];
  finalReply: string;       // reply yang aman dikirim
  triggeredHandover: boolean;
}

// ─── Pattern detectors (cepat, tanpa LLM) ────────────────────────────────────
const PRICE_PATTERN = /Rp\.?\s*[\d,.]+|[\d,.]+\s*ribu|[\d,.]+\s*juta/i;
const STOCK_PATTERN = /\b(ready|ready stok|ada stok|tersedia|masih ada|masih ready|in stock)\b/i;
const TIMELINE_PATTERN = /\b(hari ini|besok|lusa|2 hari|3 hari|minggu ini|langsung kirim|same day)\b/i;
const COMMITMENT_PATTERN = /\b(kami jamin|pasti|dijamin|100%|garansi sampai|bisa sampai|dijanjikan)\b/i;

function hasRiskyPattern(text: string): { patterns: string[]; baseScore: number } {
  const found: string[] = [];
  let score = 0;
  if (PRICE_PATTERN.test(text)) { found.push('klaim_harga'); score += 30; }
  if (STOCK_PATTERN.test(text)) { found.push('klaim_stok'); score += 25; }
  if (TIMELINE_PATTERN.test(text)) { found.push('klaim_timeline'); score += 20; }
  if (COMMITMENT_PATTERN.test(text)) { found.push('klaim_komitmen'); score += 25; }
  return { patterns: found, baseScore: Math.min(score, 100) };
}

// ─── LLM Validator (hanya jika pattern score > 0) ────────────────────────────
async function validateWithLLM(
  draftReply: string,
  userMessage: string,
  knowledgeContext: string,
): Promise<{ score: number; reasons: string[] }> {
  try {
    const resp = await groq.chat.completions.create({
      model: env.GROQ_MODEL, // model cepat cukup untuk validasi
      max_tokens: 200,
      temperature: 0,
      response_format: { type: 'json_object' },
      messages: [
        {
          role: 'system',
          content: `Kamu adalah supervisor AI Customer Service. Tugasmu: validasi apakah jawaban AI berikut AMAN untuk dikirim ke pelanggan.

PENGETAHUAN RESMI BISNIS:
${knowledgeContext || '(tidak ada knowledge yang relevan ditemukan)'}

ATURAN VALIDASI:
1. Jika jawaban menyebut harga/nominal spesifik yang TIDAK ADA di pengetahuan bisnis → BERISIKO
2. Jika jawaban mengklaim stok tersedia tanpa konfirmasi di pengetahuan → BERISIKO
3. Jika jawaban memberi janji waktu pengiriman yang tidak tercantum → BERISIKO
4. Jika jawaban bertentangan dengan informasi di pengetahuan bisnis → BERISIKO
5. Jika jawaban hanya menjelaskan secara umum tanpa klaim spesifik → AMAN

Output JSON: {"risk_score": 0-100, "reasons": ["alasan1", "alasan2"]}
risk_score 0 = sangat aman, 100 = sangat berisiko`,
        },
        {
          role: 'user',
          content: `Pesan pelanggan: "${userMessage}"\n\nJawaban AI yang akan dikirim: "${draftReply}"`,
        },
      ],
    });

    const raw = resp.choices[0]?.message?.content || '{}';
    const parsed = JSON.parse(raw);
    return {
      score: Math.min(100, Math.max(0, Number(parsed.risk_score) || 0)),
      reasons: Array.isArray(parsed.reasons) ? parsed.reasons : [],
    };
  } catch (err) {
    logger.warn(`[Supervisor] LLM validation failed, skipping: ${err}`);
    return { score: 0, reasons: [] };
  }
}

// ─── Safe Fallback Messages ───────────────────────────────────────────────────
// Pesan yang dikirim menggantikan jawaban AI yang diblokir.
//
// Sengaja ditulis seperti CS yang sedang mengecek sesuatu — bukan seperti sistem
// yang sedang mengalihkan tiket. Tidak menyebut "tim", "sistem", "dialihkan",
// dan tidak lagi mengarahkan ke "ketik 0" (opsi itu sudah dihapus). Dari sisi
// pelanggan, percakapan terasa berlanjut dengan orang yang sama; padahal di
// belakang layar percakapan sudah berpindah ke CS sungguhan.
const SAFE_FALLBACKS = [
  'Sebentar ya Kak, saya cek dulu biar infonya pasti 🙏',
  'Bentar Kak, saya pastikan dulu ya biar nggak salah kasih info 😊',
  'Saya cek dulu sebentar ya Kak, biar yang saya kasih benar-benar akurat.',
];

function getSafeFallback(): string {
  return SAFE_FALLBACKS[Math.floor(Math.random() * SAFE_FALLBACKS.length)]!;
}

// ─── Main Supervisor Validate ─────────────────────────────────────────────────
export async function supervisorValidate(
  businessId: string,
  draftReply: string,
  userMessage: string,
  conversationId: string,
  /**
   * Knowledge yang sudah diambil pemanggil (ai.service saat menyusun balasan).
   * Kalau diisi, supervisor tidak mencari ulang — menghemat satu perhitungan
   * embedding + satu query pgvector per balasan. Kalau `undefined`, supervisor
   * mencari sendiri agar tetap bisa dipakai berdiri sendiri.
   */
  knowledgeDocs?: string[],
): Promise<SupervisorResult> {
  // Step 1: pattern check (cepat, tanpa LLM)
  const { patterns, baseScore } = hasRiskyPattern(draftReply);

  // ── Step 2: LLM validation — Fix audit B3 ─────────────────────────────────
  // Dulu dibungkus `if (baseScore > 0)`, artinya validator LLM HANYA jalan
  // kalau regex sudah menemukan sesuatu. Padahal justru halusinasi yang paling
  // berbahaya adalah yang tidak terlihat seperti pola berisiko: AI mengarang
  // nama produk, salah menyebut kebijakan retur, atau membuat klaim yang
  // bertentangan dengan knowledge base tanpa menyebut angka sama sekali. Semua
  // itu lolos tanpa pernah diperiksa. Sekarang LLM selalu dijalankan.
  //
  // Biayanya satu panggilan model 8B (max 200 token) per balasan — murah, dan
  // pencarian knowledge-nya pun dioper dari ai.service jadi tidak dihitung dua kali.
  let knowledgeContext = '';
  if (knowledgeDocs !== undefined) {
    knowledgeContext = knowledgeDocs.join('\n---\n');
  } else {
    try {
      const docs = await knowledgeService.searchRelevantKnowledge(businessId, userMessage, 3);
      knowledgeContext = docs.join('\n---\n');
    } catch { /* knowledge tidak tersedia */ }
  }

  const { score: llmScore, reasons: llmReasons } = await validateWithLLM(
    draftReply, userMessage, knowledgeContext,
  );

  // ── Skoring: ambil sinyal TERTINGGI, bukan rata-rata ──────────────────────
  // Rumus lama `max(baseScore, (baseScore + llmScore) / 2)` meredam sinyal LLM
  // secara fatal saat regex diam. Contoh: regex 0, LLM 100 (yakin halusinasi)
  // → (0+100)/2 = 50 → hanya MEDIUM → tetap dikirim ke pelanggan. Artinya
  // membuka gerbang di atas saja tidak cukup; rumusnya ikut harus diperbaiki,
  // kalau tidak lubang B3 cuma berpindah tempat.
  const finalScore = Math.max(baseScore, llmScore);
  const allReasons = [...new Set([...patterns, ...llmReasons])];

  // Step 3: tentukan risk level & keputusan
  const riskLevel: RiskLevel = finalScore >= 60 ? 'HIGH' : finalScore >= 30 ? 'MEDIUM' : 'LOW';
  const approved = riskLevel !== 'HIGH';
  const triggeredHandover = riskLevel === 'HIGH';
  const finalReply = approved ? draftReply : getSafeFallback();

  logger.info(
    `[Supervisor] conv:${conversationId} | score:${finalScore} | level:${riskLevel} | approved:${approved}` +
    (allReasons.length ? ` | reasons:[${allReasons.join(', ')}]` : ''),
  );

  return {
    approved,
    riskLevel,
    riskScore: finalScore,
    riskReasons: allReasons,
    finalReply,
    triggeredHandover,
  };
}
