import { Boom } from '@hapi/boom';
import {
  makeWASocket,
  DisconnectReason,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  WASocket,
  AnyMessageContent,
  proto,
} from '@whiskeysockets/baileys';
import type { WAVersion } from '@whiskeysockets/baileys';
import pino from 'pino';
import * as QRCode from 'qrcode';
import path from 'path';
import fs from 'fs';
import { Prisma } from '@prisma/client';
import { prisma } from '../config/prisma';
import { logger } from '../utils/logger';
import { env } from '../config/env';
import { resolveIncomingJid } from '../utils/wa-jid';

interface BaileysInstance {
  sock: WASocket;
  businessId: string;
  waCredentialId: string;
  /** Kapan socket ini berhasil terhubung — dipakai mengukur umur sesi saat putus. */
  connectedAt?: number;
}

// ──────────────────────────────────────────────────────────────────────────────
// Negosiasi versi WhatsApp Web — perbaikan "Connection Failure (statusCode: 405)"
//
// Baileys memakai nomor versi WA Web yang DI-HARDCODE di lib/Defaults (pada
// 7.0.0-rc12: [2, 3000, 1035194821]). Begitu WhatsApp berhenti menerima versi
// itu, handshake ditolak dengan 405 dan QR tidak pernah terbit — persis gejala
// yang muncul 2026-07-29. Karena angkanya beku di dalam paket, menunggu update
// paket bukan solusi yang bisa diandalkan.
//
// Solusinya menanyakan versi terkini ke Baileys sebelum membuka socket. Hasilnya
// disimpan di memori proses supaya tidak menembak jaringan setiap kali connect,
// dan kalau pengambilan gagal kita diam-diam memakai versi bawaan — koneksi WA
// tidak boleh mati total hanya karena pengecekan versi tidak bisa dijangkau.
// ──────────────────────────────────────────────────────────────────────────────
let cachedWaVersion: WAVersion | null = null;

async function resolveWaVersion(): Promise<WAVersion | undefined> {
  if (cachedWaVersion) return cachedWaVersion;
  try {
    const { version, isLatest } = await fetchLatestBaileysVersion();
    cachedWaVersion = version;
    logger.info(`WA Web version: ${version.join('.')} (isLatest: ${isLatest})`);
    return version;
  } catch (err) {
    logger.warn(`Gagal mengambil versi WA Web terkini, memakai bawaan Baileys: ${err}`);
    return undefined; // makeWASocket akan memakai default paket
  }
}

/** Seberapa sering socket mati diperiksa. */
const HEALTH_CHECK_INTERVAL_MS = 30_000;

class BaileysManager {
  private instances: Map<string, BaileysInstance> = new Map();
  /**
   * Business yang sedang dalam proses connect.
   *
   * Tanpa penjaga ini, dua pemanggilan connect() yang beririsan — misalnya
   * pemulihan otomatis saat bootstrap bertabrakan dengan klik Reconnect dari
   * dashboard — sama-sama lolos pengecekan `instances.has()` (yang saat itu
   * masih kosong) lalu membuat DUA socket untuk sesi yang sama. WhatsApp
   * kemudian menendang salah satunya dengan connectionReplaced, instance-nya
   * dihapus, dan siklusnya berulang: konek sebentar lalu putus terus-menerus.
   */
  private connecting: Set<string> = new Set();
  private healthTimer: ReturnType<typeof setInterval> | null = null;
  private messageHandler: ((businessId: string, msg: proto.IWebMessageInfo) => Promise<void>) | null = null;
  private qrResolvers: Map<string, { resolve: (qr: string) => void; reject: (err: Error) => void }> = new Map();
  private reconnectCount: Map<string, number> = new Map();
  private maxReconnects = 5;

  setMessageHandler(handler: (businessId: string, msg: proto.IWebMessageInfo) => Promise<void>) {
    this.messageHandler = handler;
  }

  /**
   * Pemantau kesehatan socket.
   *
   * Baileys tidak selalu memancarkan event `close` saat koneksi mati diam-diam —
   * laptop tidur, WiFi berpindah, atau kabel dicabut bisa membuat socket jadi
   * mayat tanpa ada yang memberi tahu. Selama itu instance tetap duduk di Map,
   * status terlihat hijau, dan setiap pesan yang dikirim menguap. Pemantau ini
   * yang menyadarkannya: socket mati dibersihkan lalu disambungkan ulang.
   */
  startHealthCheck(): void {
    if (this.healthTimer) return;
    this.healthTimer = setInterval(() => {
      for (const [businessId, instance] of this.instances) {
        if (instance.sock.ws?.isOpen) continue;
        logger.warn(`[Health] Socket WA business ${businessId} sudah mati tanpa event close — dibersihkan & disambungkan ulang`);
        this.instances.delete(businessId);
        this.connect(businessId).catch(err =>
          logger.error(`[Health] Gagal menyambungkan ulang business ${businessId}: ${err}`),
        );
      }
    }, HEALTH_CHECK_INTERVAL_MS);
    logger.info(`Pemantau kesehatan socket WA aktif (tiap ${HEALTH_CHECK_INTERVAL_MS / 1000} detik)`);
  }

  stopHealthCheck(): void {
    if (this.healthTimer) {
      clearInterval(this.healthTimer);
      this.healthTimer = null;
    }
  }

  getSessionDir(businessId: string): string {
    const dir = path.resolve(env.WA_SESSIONS_DIR, businessId);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    return dir;
  }

  async connect(businessId: string, waitForQR: boolean = false): Promise<string | void> {
    // Satu proses connect per business pada satu waktu — lihat catatan di field
    // `connecting` soal socket ganda yang saling menendang.
    if (this.connecting.has(businessId)) {
      logger.warn(`Permintaan connect untuk business ${businessId} diabaikan: masih ada proses connect berjalan`);
      return;
    }
    this.connecting.add(businessId);
    try {
      return await this.doConnect(businessId, waitForQR);
    } finally {
      this.connecting.delete(businessId);
    }
  }

  private async doConnect(businessId: string, waitForQR: boolean = false): Promise<string | void> {
    if (this.instances.has(businessId)) {
      const existing = this.instances.get(businessId)!;
      const waId = existing.sock.user?.id;
      if (waitForQR) {
        if (waId) {
          const cred = await prisma.waCredential.findFirst({ where: { businessId } });
          if (cred?.qrCode) return cred.qrCode;
        }
        await this.disconnect(businessId);
      } else {
        if (waId) return;
        await this.disconnect(businessId);
      }
    }

    if (this.instances.size >= env.WA_MAX_CONNECTIONS) {
      throw new Error('Server at capacity: max WA connections reached');
    }

    const cred = await prisma.waCredential.findFirst({
      where: { businessId, status: { not: 'BANNED' } },
    });

    if (!cred) {
      throw new Error('No WhatsApp credential found for this business');
    }

    const sessionDir = this.getSessionDir(businessId);
    const credsPath = path.join(sessionDir, 'creds.json');

    // ── Disk adalah sumber kebenaran; DB hanya cadangan untuk cold start ──────
    // Sebelumnya creds.json SELALU ditimpa dari salinan database setiap connect.
    // Itu berbahaya: yang tersimpan di DB HANYA creds.json, sementara sesi
    // Baileys yang hidup terdiri dari ratusan file lain (pre-key, identity-key,
    // session, app-state-sync) yang cuma ada di disk. Menimpa creds.json dengan
    // salinan DB yang lebih tua sementara file kunci lain sudah lebih baru
    // membuat sesi jadi tidak konsisten. Sekarang DB hanya dipakai kalau disk
    // memang kosong — misal folder sesi terhapus atau pindah mesin.
    if (!fs.existsSync(credsPath) && cred.sessionData) {
      const sessionData = cred.sessionData as any;
      if (sessionData.creds) {
        fs.writeFileSync(credsPath, JSON.stringify(sessionData.creds, null, 2));
        logger.info(`Sesi WA dipulihkan dari database untuk business ${businessId} (disk kosong)`);
      }
    }

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

    // Wajib sebelum membuka socket — lihat catatan 405 di atas.
    const waVersion = await resolveWaVersion();

    const sock = makeWASocket({
      auth: state,
      ...(waVersion ? { version: waVersion } : {}),
      syncFullHistory: false,
      emitOwnEvents: false,
      browser: ['SalesPintar', 'Chrome', '120.0'],
      logger: pino({ level: 'warn' }),
    });

    const instance: BaileysInstance = { sock, businessId, waCredentialId: cred.id };
    this.instances.set(businessId, instance);

    sock.ev.on('creds.update', async () => {
      await saveCreds();
      try {
        const credsPath = path.join(sessionDir, 'creds.json');
        if (fs.existsSync(credsPath)) {
          const credsData = JSON.parse(fs.readFileSync(credsPath, 'utf-8'));
          await prisma.waCredential.update({
            where: { id: cred.id },
            data: { sessionData: { creds: credsData } },
          });
        }
      } catch (err) {
        logger.error(`Failed to save creds for business ${businessId}`);
      }
    });

    sock.ev.on('connection.update', async (update) => {
      const { connection, lastDisconnect, qr } = update;

      if (qr) {
        const qrBase64 = await QRCode.toDataURL(qr);
        await prisma.waCredential.update({
          where: { id: cred.id },
          data: {
            qrCode: qrBase64,
            qrExpiresAt: new Date(Date.now() + 60000),
            status: 'DISCONNECTED',
          },
        });
        const entry = this.qrResolvers.get(businessId);
        if (entry) {
          entry.resolve(qrBase64);
          this.qrResolvers.delete(businessId);
        }
        logger.info(`QR generated for business ${businessId}`);
      }

      if (connection === 'open') {
        const waId = sock.user?.id;
        if (!waId) return;
        const waNumber = waId?.split(':')[0]?.replace('@s.whatsapp.net', '') || '';
        await prisma.waCredential.update({
          where: { id: cred.id },
          data: {
            status: 'CONNECTED',
            waId,
            waNumber,
            qrCode: null,
            qrExpiresAt: null,
            lastConnectedAt: new Date(),
          },
        });
        // Percobaan reconnect dianggap lunas begitu sambungan berhasil.
        // Tanpa ini counter-nya kumulatif seumur hidup proses: lima kali putus
        // sepanjang hari — walau tiap sambungan berikutnya sukses — membuat
        // kode berhenti mencoba SELAMANYA.
        this.reconnectCount.delete(businessId);
        instance.connectedAt = Date.now();

        // Kalau sesi lama masih sah, WhatsApp langsung membuka koneksi tanpa
        // pernah menerbitkan QR. Permintaan /wa/qr yang sedang menunggu harus
        // dibebaskan di sini — kalau tidak, ia menggantung sampai timeout 60
        // detik lalu melapor "QR timeout" padahal sambungannya justru berhasil.
        const pendingQr = this.qrResolvers.get(businessId);
        if (pendingQr) {
          pendingQr.resolve(''); // string kosong = tersambung, QR tidak diperlukan
          this.qrResolvers.delete(businessId);
        }

        logger.info(`WhatsApp connected for business ${businessId} [PID ${process.pid}]`);
      }

      if (connection === 'close') {
        const err = lastDisconnect?.error as Boom;
        const statusCode = err?.output?.statusCode;
        const reason = err?.message || 'unknown';
        // Umur sesi adalah petunjuk paling menentukan. Putus dalam hitungan detik
        // menunjuk ke penolakan dari sisi WhatsApp atau socket ganda; putus setelah
        // belasan menit lebih menunjuk ke jaringan atau laptop tidur.
        const uptimeText = instance.connectedAt
          ? `${Math.round((Date.now() - instance.connectedAt) / 1000)} detik`
          : 'belum pernah tersambung';
        logger.warn(
          `WhatsApp closed for business ${businessId}: ${reason} (statusCode: ${statusCode}) ` +
          `| umur sesi: ${uptimeText} | PID ${process.pid}`,
        );
        this.instances.delete(businessId);
        logger.info(`WhatsApp disconnected for business ${businessId}`);

        const entry = this.qrResolvers.get(businessId);
        if (entry) {
          entry.reject(new Error(`QR gagal: ${reason} (statusCode: ${statusCode})`));
          this.qrResolvers.delete(businessId);
        }

        // ── loggedOut (401): sesi dicabut dari sisi WhatsApp ────────────────
        // Perangkat sudah dilepas dari daftar Linked Device. Mencoba menyambung
        // ulang dengan kredensial yang sama percuma dan justru bisa memancing
        // pembatasan. Bersihkan sesinya supaya scan berikutnya mulai dari bersih.
        if (statusCode === DisconnectReason.loggedOut) {
          logger.warn(`WhatsApp logged out untuk business ${businessId} — sesi dibersihkan, perlu scan ulang`);
          await this.clearSession(businessId, cred.id);
          return;
        }

        await prisma.waCredential.update({
          where: { id: cred.id },
          data: { status: 'DISCONNECTED' },
        });

        // ── connectionReplaced (440): sesi diambil alih koneksi lain ───────
        // Bisa karena WhatsApp Web dibuka di tempat lain, atau karena ada DUA
        // socket dari aplikasi ini sendiri. Menyambung ulang di sini justru
        // memulai perang rebutan: dua socket saling menendang tanpa henti,
        // gejalanya "konek sebentar lalu putus" berulang-ulang. Berhenti dan
        // laporkan; biarkan manusia yang memutuskan.
        if (statusCode === DisconnectReason.connectionReplaced) {
          logger.warn(`Sesi WA business ${businessId} diambil alih koneksi lain — TIDAK menyambung ulang otomatis. Pastikan hanya satu proses backend yang jalan, lalu Reconnect manual.`);
          return;
        }

        // ── restartRequired (515): langkah normal, bukan kegagalan ─────────
        // WhatsApp SELALU mengirim ini tepat setelah pairing QR berhasil — dia
        // memang meminta klien menyambung ulang. Kalau diperlakukan seperti
        // kegagalan biasa, ia menghabiskan satu jatah percobaan dan menunggu
        // backoff 5 detik, padahal seharusnya langsung saja.
        if (statusCode === DisconnectReason.restartRequired) {
          logger.info(`WhatsApp minta restart untuk business ${businessId} — menyambung ulang segera`);
          setTimeout(() => {
            this.connect(businessId).catch(err =>
              logger.error(`Gagal menyambung ulang setelah restartRequired (${businessId}): ${err}`),
            );
          }, 1000);
          return;
        }

        const shouldReconnect =
          statusCode === DisconnectReason.connectionLost ||
          statusCode === DisconnectReason.connectionClosed ||
          statusCode === DisconnectReason.timedOut;

        if (shouldReconnect) {
          const attempts = this.reconnectCount.get(businessId) || 0;
          if (attempts < this.maxReconnects) {
            this.reconnectCount.set(businessId, attempts + 1);
            const delay = Math.min(5000 * Math.pow(2, attempts), 60000);
            logger.info(`Reconnecting WhatsApp for business ${businessId} (attempt ${attempts + 1}/${this.maxReconnects})...`);
            setTimeout(() => {
              this.connect(businessId).catch(err =>
                logger.error(`Gagal menyambung ulang business ${businessId}: ${err}`),
              );
            }, delay);
          } else {
            logger.warn(`Max reconnection attempts reached for business ${businessId}`);
            this.reconnectCount.delete(businessId);
          }
        }
      }
    });

    sock.ev.on('messages.upsert', async (msg) => {
      for (const message of msg.messages) {
        if (message.key.fromMe) continue;
        // Saring sedini mungkin supaya status/channel/grup tidak pernah
        // menyentuh pipeline pesan sama sekali.
        if (!resolveIncomingJid(message.key)) continue;
        if (this.messageHandler) {
          await this.messageHandler(businessId, message);
        }
      }
    });

    if (waitForQR) {
      return this.waitForQR(businessId);
    }
  }

  private waitForQR(businessId: string): Promise<string> {
    return new Promise((resolve, reject) => {
      this.qrResolvers.set(businessId, { resolve, reject });
      setTimeout(() => {
        const entry = this.qrResolvers.get(businessId);
        if (entry) {
          this.qrResolvers.delete(businessId);
          reject(new Error('QR timeout'));
        }
      }, 60000);
    });
  }

  /**
   * Buang sesi WhatsApp sepenuhnya — file kunci di disk maupun salinan di DB.
   * Dipakai saat WhatsApp mencabut sesi (loggedOut): kredensialnya sudah tidak
   * ada artinya, dan menyisakannya hanya akan membuat percobaan berikutnya
   * memakai kunci mati.
   */
  private async clearSession(businessId: string, credentialId: string): Promise<void> {
    try {
      const dir = path.resolve(env.WA_SESSIONS_DIR, businessId);
      if (fs.existsSync(dir)) {
        fs.rmSync(dir, { recursive: true, force: true });
      }
    } catch (err) {
      logger.error(`Gagal menghapus folder sesi WA ${businessId}: ${err}`);
    }

    this.reconnectCount.delete(businessId);

    try {
      await prisma.waCredential.update({
        where: { id: credentialId },
        // Prisma.DbNull, BUKAN undefined. Untuk kolom Json, `undefined` berarti
        // "jangan sentuh field ini" — jadi kredensial mati justru akan tetap
        // tersimpan dan dipakai lagi saat cold start berikutnya. `Prisma.DbNull`
        // yang benar-benar menulis NULL ke database.
        data: { status: 'DISCONNECTED', sessionData: Prisma.DbNull, qrCode: null, qrExpiresAt: null },
      });
    } catch (err) {
      logger.error(`Gagal membersihkan kredensial WA ${businessId}: ${err}`);
    }
  }

  async disconnect(businessId: string): Promise<void> {
    const instance = this.instances.get(businessId);
    if (instance) {
      instance.sock.end(new Error('Disconnected by user'));
      this.instances.delete(businessId);
    }

    await prisma.waCredential.updateMany({
      where: { businessId },
      data: { status: 'DISCONNECTED', qrCode: null, qrExpiresAt: null },
    });
  }

  getStatus(businessId: string): string {
    const instance = this.instances.get(businessId);
    if (!instance) return 'DISCONNECTED';

    // ── Wajib memeriksa DUA hal, bukan salah satunya ──────────────────────────
    // Versi lama hanya mengecek `sock.user?.id`. Masalahnya, properti itu diisi
    // SEKALI saat pairing berhasil dan tidak pernah dihapus lagi — ia menempel di
    // objek socket selamanya. Jadi selama instance masih ada di Map, status
    // dilaporkan CONNECTED walaupun WebSocket-nya sudah lama mati. Ini yang
    // membuat dashboard menampilkan hijau padahal pesan tidak bisa dikirim, dan
    // membuat pengecekan isConnected() di broadcast serta pengiriman pesan CS
    // lolos padahal seharusnya menolak.
    //
    // Komentar lama di sini berbunyi "readyState hanya menandakan koneksi
    // internet, kita harus cek autentikasi" — benar, tapi jawabannya bukan
    // membuang pengecekan socket, melainkan memeriksa keduanya: socket harus
    // HIDUP dan user harus SUDAH terotentikasi.
    if (!instance.sock.ws?.isOpen) return 'DISCONNECTED';
    if (instance.sock.user?.id) return 'CONNECTED';
    return 'PENDING';
  }

  async sendMessage(businessId: string, jid: string, content: AnyMessageContent): Promise<any> {
    const instance = this.instances.get(businessId);
    if (!instance) throw new Error(`WhatsApp not connected for business ${businessId}`);
    // Socket bisa saja mati tanpa event close sempat terpicu (laptop tidur,
    // ganti jaringan). Menolak di sini lebih baik daripada menggantung lama
    // lalu gagal diam-diam.
    if (!instance.sock.ws?.isOpen) {
      throw new Error(`WhatsApp socket tidak aktif untuk business ${businessId}`);
    }
    return instance.sock.sendMessage(jid, content);
  }

  async sendTyping(businessId: string, jid: string): Promise<void> {
    const instance = this.instances.get(businessId);
    if (!instance) return;
    await instance.sock.sendPresenceUpdate('composing', jid);
  }

  getTotalConnections(): number {
    return this.instances.size;
  }

  isConnected(businessId: string): boolean {
    return this.instances.has(businessId) && this.getStatus(businessId) === 'CONNECTED';
  }

  async disconnectAll(): Promise<void> {
    for (const [businessId] of this.instances) {
      await this.disconnect(businessId);
    }
  }

  async connectAllActive(): Promise<void> {
    const activeCreds = await prisma.waCredential.findMany({
      where: { status: 'CONNECTED', business: { isActive: true } },
      include: { business: true },
    });

    for (const cred of activeCreds) {
      try {
        await this.connect(cred.businessId);
      } catch (err) {
        logger.error(`Failed to reconnect business ${cred.businessId}: ${err}`);
      }
    }
  }
}

export const baileysManager = new BaileysManager();
