(function() {
    // Pastikan data konfigurasi tersedia dari PHP (wp_localize_script)
    if (typeof spCapiBridgeData === 'undefined' || !spCapiBridgeData.businessId) {
        return;
    }

    const businessId = spCapiBridgeData.businessId;
    const apiUrl = spCapiBridgeData.apiUrl;

    // Helper: Baca cookie
    function getCookie(name) {
        const value = `; ${document.cookie}`;
        const parts = value.split(`; ${name}=`);
        if (parts.length === 2) return parts.pop().split(';').shift();
        return null;
    }

    // Helper: Ambil parameter dari URL
    function getUrlParameter(name) {
        name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
        var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
        var results = regex.exec(location.search);
        return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
    }

    // Ekstrak FBP & FBC
    function getMetaCookies() {
        let fbp = getCookie('_fbp');
        let fbc = getCookie('_fbc');

        // FASE 1: Fallback jika fbc belum dibuat oleh Pixel tapi fbclid ada di URL (Race Condition)
        if (!fbc) {
            const fbclid = getUrlParameter('fbclid');
            if (fbclid) {
                fbc = `fb.1.${Date.now()}.${fbclid}`;
            }
        }

        return { fbp, fbc };
    }

    // Helper: Tembus Shadow DOM untuk mencari form input
    function findInputInShadowDOM(rootNode, selectors) {
        // Coba di root node (Light DOM) dulu
        let input = rootNode.querySelector(selectors);
        if (input) return input;

        // Cari di anak-anak yang mungkin punya shadowRoot (seperti forms.id)
        const allNodes = rootNode.querySelectorAll('*');
        for (let i = 0; i < allNodes.length; i++) {
            if (allNodes[i].shadowRoot) {
                input = allNodes[i].shadowRoot.querySelector(selectors);
                if (input) return input;
                // Rekursif ke dalam shadow dom
                input = findInputInShadowDOM(allNodes[i].shadowRoot, selectors);
                if (input) return input;
            }
        }
        return null;
    }

    // Eksekutor pengiriman data ke SalesPintar
    function sendAttribution(phoneInput, nameInput) {
        const waNumber = phoneInput ? phoneInput.value : '';
        if (!waNumber || waNumber.length < 9) return; // Minimal 9 digit

        const name = nameInput ? nameInput.value : '';
        const { fbp, fbc } = getMetaCookies();
        const productName = document.title; // Default nama produk dari title halaman

        const payload = {
            businessId: businessId,
            waNumber: waNumber,
            name: name,
            fbp: fbp,
            fbc: fbc,
            userAgent: navigator.userAgent,
            landingUrl: window.location.href,
            productName: productName
        };

        const blob = new Blob([JSON.stringify(payload)], { type: 'application/json' });
        
        // Gunakan sendBeacon agar request tetap jalan meskipun browser redirect ke WA
        if (navigator.sendBeacon) {
            navigator.sendBeacon(apiUrl, blob);
        } else {
            // Fallback untuk browser lawas
            fetch(apiUrl, {
                method: 'POST',
                body: JSON.stringify(payload),
                headers: { 'Content-Type': 'application/json' },
                keepalive: true
            }).catch(e => console.error(e));
        }
    }

    // Listener global untuk klik tombol submit / pesan
    document.addEventListener('click', function(e) {
        // Cek apakah yang diklik adalah tombol submit/pesan
        // Biasanya forms.id / element lain pakai type="submit" atau class khusus
        const target = e.target.closest('button, input[type="submit"], input[type="button"], a');
        if (!target) return;

        const text = (target.innerText || target.value || '').toLowerCase();
        // Heuristic: tombol yang mengarah ke WA atau submit form
        if (
            target.type === 'submit' || 
            text.includes('pesan') || 
            text.includes('beli') || 
            text.includes('wa') || 
            text.includes('whatsapp') || 
            text.includes('submit') || 
            target.closest('form')
        ) {
            // Coba temukan input Nomor HP di halaman (baik Light DOM maupun Shadow DOM)
            const phoneInput = findInputInShadowDOM(document.body, 'input[type="tel"], input[name*="phone"], input[name*="wa"], input[placeholder*="WA"], input[placeholder*="WhatsApp"]');
            
            // Coba temukan input Nama
            const nameInput = findInputInShadowDOM(document.body, 'input[type="text"][name*="name"], input[placeholder*="Nama"]');
            
            if (phoneInput && phoneInput.value) {
                sendAttribution(phoneInput, nameInput);
            }
        }
    }, true); // Use capture phase to catch event early

})();
